"""
src/llm/agent.py
================
Groq LLM Agent — used EXCLUSIVELY for physics reasoning within the
prediction pipeline.  Three functions only:

  1. rank_and_select()           – Pick best CFD case(s) from top-k candidates
                                   based on wind direction, Re, geometry similarity.
                                   Returns JSON weights for field blending.

  2. validate_field_statistics() – Verify generated p/U statistics against
                                   incompressible NS physics bounds
                                   (Bernoulli, Cp limits, continuity).

  3. compute_optimal_orientation()– Compute optimal building rotation angle
                                   to minimise structural wind loading,
                                   using Cp distributions from the analysis.

NO chatbot. NO Q&A. NO interactive session. These are pure data-in → JSON-out
functions called automatically by the pipeline.
"""
from __future__ import annotations

import json
from typing import Dict, Any, List, Tuple, Optional

import numpy as np
from groq import Groq

import config


# ─────────────────────────────────────────────────────────────────────────────
# System prompt: physics expert, structured JSON outputs only
# ─────────────────────────────────────────────────────────────────────────────
_SYS = """You are a senior CFD engineer and numerical methods expert.
You work exclusively with OpenFOAM incompressible steady RANS simulations
(simpleFoam, k-epsilon turbulence model).

Your role in this system is to make structured physics-based decisions that
feed into an automated RAG prediction pipeline.
You never converse, never ask questions, never explain basics.
You only produce the exact JSON output requested.

Core physics you apply:
  Governing:  ∇·u=0  |  (u·∇)u = -∇(p/ρ) + ∇·[(ν+νt)∇u]
  Turbulence: νt = Cμ k²/ε   k=1.5(IU)²   ε=Cμ^0.75 k^1.5/L
  Scaling:    u∝U  |  p∝U²  |  k∝U²  |  ε∝U³
  Bernoulli:  Cp_stagnation=+1.0  |  Cp_separation≈-0.5 to -1.5
  Wake:       length ≈ 10-20×H_building  |  Re-independence for Re>10^4
  ABL:        u(z) = u_ref(z/z_ref)^0.25  (suburban terrain)

Wind direction is the PRIMARY matching criterion for Cp field topology.
"""


class GroqCFDAgent:

    def __init__(self, api_key: Optional[str] = None,
                 model: Optional[str] = None):
        self._g = Groq(api_key=api_key or config.GROQ_API_KEY)
        self._m = model or config.GROQ_MODEL

    def _call(self, prompt: str, max_tokens: int = 1024,
              temp: float = 0.05) -> str:
        r = self._g.chat.completions.create(
            model=self._m,
            messages=[{"role": "system", "content": _SYS},
                      {"role": "user",   "content": prompt}],
            max_tokens=max_tokens, temperature=temp,
        )
        return r.choices[0].message.content.strip()

    @staticmethod
    def _parse_json(raw: str) -> dict:
        raw = raw.strip()
        if "```" in raw:
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        return json.loads(raw.strip())

    # ─────────────────────────────────────────────────────────────────────────
    # 1. rank_and_select
    # ─────────────────────────────────────────────────────────────────────────
    def rank_and_select(self,
                        q_feat:     Dict[str, float],
                        q_raw:      Dict[str, Any],
                        candidates: List[Dict[str, Any]]) -> dict:
        """
        Select and weight the best matching CFD cases for field blending.

        Returns
        -------
        {
          best_case_id               : str,
          selected_cases             : [{id, weight, reason}],
          blend_strategy             : "nearest_neighbour" | "weighted_blend",
          magnitude_scaling_ratio    : float,
          azimuth_correction_needed  : bool,
          geometry_similarity_concern: "none"|"minor"|"major",
          reasoning                  : str   (1-2 sentences)
        }
        """
        Ux, Uy, Uz = q_raw["inlet_velocity"]
        U_mag  = q_feat.get("inlet_magnitude", 0)
        azi    = q_feat.get("inlet_azimuth_deg", 0)
        Re     = q_feat.get("Re_building", 0)
        H      = q_feat.get("geom_max_height", 0)

        clist = []
        for i, c in enumerate(candidates):
            m = c["metadata"]
            clist.append(
                f"[{i}] id={c['id']}  sim={c['similarity']:.4f}  "
                f"inlet=({m.get('inlet_Ux',0):.3f},{m.get('inlet_Uy',0):.3f},{m.get('inlet_Uz',0):.3f})  "
                f"|U|={m.get('inlet_magnitude',0):.3f}  azi={m.get('inlet_azimuth_deg',0):.1f}°  "
                f"H={m.get('geom_max_height',0):.1f}m  Re={m.get('Re_building',0):.2e}"
            )

        prompt = f"""
QUERY:
  inlet = ({Ux:.3f},{Uy:.3f},{Uz:.3f}) m/s   |U|={U_mag:.3f}   azimuth={azi:.1f}°
  Re = {Re:.2e}   H_building = {H:.1f} m

TOP-K CANDIDATES:
{chr(10).join(clist)}

TASK: Select the best case(s) for physics-based field blending.

DECISION RULES:
1. Azimuth match is PRIMARY. Δazimuth>45° means completely different Cp topology.
2. If best azimuth match has sim<0.7, blend top-2 by azimuth proximity.
3. Magnitude difference is corrected by scaling (p∝U², u∝U) — not a selection concern.
4. Geometry (H, aspect) affects wake length — prefer close H match for near-field accuracy.
5. Use "nearest_neighbour" if best sim>0.85, else "weighted_blend".

OUTPUT ONLY this exact JSON (no other text):
{{
  "best_case_id": "<id>",
  "selected_cases": [
    {{"id": "<id>", "weight": 0.0, "reason": "<10 words>"}},
    ...
  ],
  "blend_strategy": "nearest_neighbour",
  "magnitude_scaling_ratio": 1.0,
  "azimuth_correction_needed": false,
  "geometry_similarity_concern": "none",
  "reasoning": "<2 sentences max>"
}}
Weights must sum to exactly 1.0.
"""
        try:
            raw  = self._call(prompt, max_tokens=600, temp=0.02)
            return self._parse_json(raw)
        except Exception:
            # Physics fallback: pick case with closest azimuth
            return _fallback_selection(candidates, azi, U_mag)

    # ─────────────────────────────────────────────────────────────────────────
    # 2. validate_field_statistics
    # ─────────────────────────────────────────────────────────────────────────
    def validate_field_statistics(self,
                                   p_stats:    Dict[str, float],
                                   U_stats:    Dict[str, float],
                                   inlet:      Tuple[float, float, float],
                                   L_ref:      float) -> dict:
        """
        Validate predicted field statistics against incompressible NS physics.

        Returns
        -------
        {
          Cp_max_actual, Cp_min_actual, U_max_ratio, U_mean_ratio,
          is_physically_valid, warnings, confidence, verdict
        }
        """
        U_in   = float(np.linalg.norm(inlet))
        q      = 0.5 * U_in**2 + 1e-9
        Re     = U_in * L_ref / config.NU
        cp_max = (p_stats["p_max"] - p_stats["p_mean"]) / q
        cp_min = (p_stats["p_min"] - p_stats["p_mean"]) / q
        ur     = U_stats["U_mag_max"] / max(U_in, 1e-9)
        umr    = U_stats["U_mag_mean"] / max(U_in, 1e-9)

        prompt = f"""
PREDICTED FIELD STATISTICS (OpenFOAM kinematic pressure p/ρ [m²/s²]):
  p_mean={p_stats['p_mean']:.4f}  p_max={p_stats['p_max']:.4f}
  p_min={p_stats['p_min']:.4f}   p_std={p_stats['p_std']:.4f}
  U_mag_mean={U_stats['U_mag_mean']:.4f}  U_mag_max={U_stats['U_mag_max']:.4f}
  U_mag_min={U_stats['U_mag_min']:.4f}   U_mag_std={U_stats['U_mag_std']:.4f}

DERIVED:
  |U_inlet|   = {U_in:.4f} m/s
  q_kinematic = {q:.4f} m²/s²
  Re          = {Re:.3e}
  Cp_max      = {cp_max:.4f}   (expected: ≤1.05 for stagnation)
  Cp_min      = {cp_min:.4f}   (expected: ≥-3.0 practical limit)
  U_max/U_in  = {ur:.4f}      (expected: ≤3.0 for Venturi corridors)
  U_mean/U_in = {umr:.4f}     (expected: 0.55-0.85 bulk flow)

Validate against incompressible NS physics.
OUTPUT ONLY this exact JSON:
{{
  "Cp_max_actual": {round(cp_max,4)},
  "Cp_min_actual": {round(cp_min,4)},
  "U_max_ratio": {round(ur,4)},
  "U_mean_ratio": {round(umr,4)},
  "is_physically_valid": true,
  "warnings": [],
  "confidence": "high",
  "verdict": "<one sentence>"
}}
"""
        try:
            raw = self._call(prompt, max_tokens=400, temp=0.02)
            return self._parse_json(raw)
        except Exception:
            return _fallback_validate(p_stats, U_stats, inlet)

    # ─────────────────────────────────────────────────────────────────────────
    # 3. compute_optimal_orientation
    # ─────────────────────────────────────────────────────────────────────────
    def compute_optimal_orientation(self,
                                     analysis:      Dict[str, Any],
                                     geom_features: Dict[str, float],
                                     inlet:         Tuple[float, float, float]) -> str:
        """
        Compute the optimal building rotation to minimise structural loading.

        Returns a plain-text engineering recommendation (not JSON).
        Covers:
          - Current structural risk assessment
          - Optimal rotation angle (degrees) for minimum ΔP
          - Expected ΔCp reduction
          - Natural ventilation trade-off angle
        """
        risk = analysis.get("structural_risk", {})
        wake = analysis.get("wake_region", {})
        vent = analysis.get("venturi", {})
        azi  = float(np.degrees(np.arctan2(inlet[1], inlet[0])))
        H    = geom_features.get("geom_max_height", 60)
        asp  = geom_features.get("geom_aspect_ratio_xy", 1.0)
        pa   = geom_features.get("geom_principal_angle_deg", 0.0)

        prompt = f"""
BUILDING CFD ANALYSIS RESULTS:
  Wind azimuth            : {azi:.1f}°  (0°=East, 90°=North)
  Building height         : {H:.1f} m
  XY aspect ratio (Lx/Ly) : {asp:.3f}
  Principal axis angle    : {pa:.1f}°

CURRENT FLOW RESULTS:
  Structural risk         : {risk.get('risk_level','?')}
  Cp_windward_max         : {risk.get('Cp_windward_max',0):.4f}
  Cp_leeward_min          : {risk.get('Cp_leeward_min',0):.4f}
  ΔP                      : {risk.get('p_differential_Pa',0):.2f} Pa
  Wake fraction           : {wake.get('wake_fraction',0)*100:.1f}%
  Recirculation fraction  : {wake.get('recirculation_fraction',0)*100:.1f}%
  Max speed ratio         : {vent.get('max_speed_ratio',1):.3f}×

Compute optimal building orientation.

Apply these wind engineering principles:
  1. Corner-on (45°): reduces frontal area for square plans → ΔCp ≈ -15 to -20%
  2. Long axis ∥ wind: minimum drag for elongated plans (asp>2.0)
  3. Long axis ⊥ wind: maximum natural cross-ventilation
  4. For asp near 1.0 (square): 45° typically gives lowest Cp_windward
  5. Estimate ΔCp reduction using: ΔCp ≈ (Cp_current - Cp_optimal) / Cp_current

Write a concise engineering recommendation (4-6 lines) covering:
  A. Optimal rotation angle to minimise structural loading (give exact degrees)
  B. Expected % reduction in peak Cp and ΔP
  C. Secondary angle for maximum natural ventilation
  D. One-line summary of trade-off between structural and ventilation goals
"""
        return self._call(prompt, max_tokens=400, temp=0.15)


# ─────────────────────────────────────────────────────────────────────────────
# Physics fallbacks (no LLM needed)
# ─────────────────────────────────────────────────────────────────────────────

def _fallback_selection(candidates, query_azi, query_umag):
    """Pick case with closest wind azimuth — pure physics, no LLM."""
    best_i, best_da = 0, 999.0
    for i, c in enumerate(candidates):
        m  = c["metadata"]
        da = abs(m.get("inlet_azimuth_deg", 0) - query_azi) % 360
        da = min(da, 360 - da)
        if da < best_da:
            best_da, best_i = da, i

    best = candidates[best_i]
    ref_umag = best["metadata"].get("inlet_magnitude", max(query_umag, 1e-9))
    scale = query_umag / max(ref_umag, 1e-9)

    return {
        "best_case_id":    best["id"],
        "selected_cases":  [{"id": best["id"], "weight": 1.0,
                              "reason": f"Closest azimuth (Δ{best_da:.1f}°)"}],
        "blend_strategy":  "nearest_neighbour",
        "magnitude_scaling_ratio": round(scale, 4),
        "azimuth_correction_needed": best_da > 15,
        "geometry_similarity_concern": "unknown",
        "reasoning": f"Selected by minimum azimuth difference {best_da:.1f}°. "
                     f"Magnitude ratio ×{scale:.3f}.",
    }


def _fallback_validate(ps, Us, inlet):
    q   = 0.5 * float(np.linalg.norm(inlet))**2 + 1e-9
    cpm = (ps["p_max"] - ps["p_mean"]) / q
    cpn = (ps["p_min"] - ps["p_mean"]) / q
    ur  = Us["U_mag_max"] / max(float(np.linalg.norm(inlet)), 1e-9)
    wr  = []
    if cpm > 1.05: wr.append(f"Cp_max={cpm:.3f} > 1.05")
    if cpn < -3.5: wr.append(f"Cp_min={cpn:.3f} < -3.5")
    if ur  > 4.0:  wr.append(f"U_max/U_in={ur:.3f} > 4.0")
    ok = len(wr) == 0
    return {
        "Cp_max_actual": round(cpm, 4), "Cp_min_actual": round(cpn, 4),
        "U_max_ratio": round(ur, 4),
        "U_mean_ratio": round(Us["U_mag_mean"] / max(float(np.linalg.norm(inlet)), 1e-9), 4),
        "is_physically_valid": ok, "warnings": wr,
        "confidence": "medium",
        "verdict": "Fields physically consistent." if ok else f"Issues: {'; '.join(wr)}",
    }
