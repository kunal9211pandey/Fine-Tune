"""
Flow Analyzer: Extract physically meaningful insights from CFD fields.

Analyzes:
  1. Boundary / wake regions   – low velocity behind buildings
  2. Weak structural regions   – high pressure difference zones (windward vs leeward)
  3. Inlet airflow pattern     – upstream approach flow characteristics
  4. Recirculation zones       – negative streamwise velocity regions
  5. Wind acceleration corridors – high velocity between buildings (Venturi effect)
  6. Stagnation points         – zero velocity + high pressure on windward face
  7. Building surroundings     – complete near-field analysis

All analysis is performed on the 1D arrays read from OpenFOAM field files.
Cell coordinates are reconstructed from bounding-box heuristics since we
don't load the full polyMesh (too large for RAG pipeline).
"""
import numpy as np
from typing import Dict, Any, List, Tuple, Optional
import config


# ────────────────────────────────────────────────────────────────────────────
# Statistical zone detection
# ────────────────────────────────────────────────────────────────────────────

def detect_high_pressure_zones(p_field: np.ndarray,
                                 U_inlet_mag: float,
                                 n_quantile: float = 0.95) -> Dict[str, Any]:
    """
    Identify high-pressure regions (windward building faces, stagnation).

    Physics: stagnation pressure = 0.5 ρ U²  →  p_stag ≈ 0.5 U_inlet²  (kinematic)
    Cells with p > q_th are likely on windward faces.
    """
    q_dyn   = 0.5 * U_inlet_mag ** 2     # dynamic pressure (kinematic)
    p_thresh = np.quantile(p_field, n_quantile)
    p_stag_theoretical = q_dyn           # Cp = 1 at stagnation

    high_p_mask  = p_field > p_thresh
    n_high       = int(high_p_mask.sum())
    p_max_actual = float(p_field.max())
    cp_max       = (p_max_actual - float(p_field.mean())) / max(q_dyn, 1e-9)

    return {
        'n_high_pressure_cells': n_high,
        'p_threshold':           float(p_thresh),
        'p_max':                 p_max_actual,
        'p_stagnation_theory':   float(p_stag_theoretical),
        'Cp_max':                float(cp_max),
        'fraction_high_p':       float(n_high / len(p_field)),
        'interpretation':        (
            "Strong windward stagnation present"
            if cp_max > 0.6 else
            "Moderate windward pressure"
        ),
    }


def detect_low_pressure_zones(p_field: np.ndarray,
                                U_inlet_mag: float,
                                n_quantile: float = 0.05) -> Dict[str, Any]:
    """
    Identify low-pressure / wake / separation regions (leeward faces, rooftop).

    Physics: separation → p < p_ambient → Cp < 0
    Strong suction (Cp < -1) indicates attached separation.
    """
    q_dyn    = 0.5 * U_inlet_mag ** 2
    p_thresh = np.quantile(p_field, n_quantile)
    p_min_actual = float(p_field.min())
    cp_min   = (p_min_actual - float(p_field.mean())) / max(q_dyn, 1e-9)

    low_p_mask = p_field < p_thresh
    n_low      = int(low_p_mask.sum())

    return {
        'n_low_pressure_cells': n_low,
        'p_threshold':          float(p_thresh),
        'p_min':                p_min_actual,
        'Cp_min':               float(cp_min),
        'fraction_low_p':       float(n_low / len(p_field)),
        'interpretation':       (
            "Severe suction – roof/leeward separation"
            if cp_min < -1.5 else
            "Moderate suction zones present" if cp_min < -0.5 else
            "Mild suction zones"
        ),
    }


def detect_wake_region(U_field: np.ndarray,
                        U_inlet: Tuple[float, float, float]) -> Dict[str, Any]:
    """
    Detect wake region: low-velocity cells aligned with wind direction.

    Physics: wake → |u| << U_inlet; possible recirculation (u_streamwise < 0)
    Wake fraction indicates extent of disturbed flow.
    """
    U_mag    = np.linalg.norm(U_field, axis=1)
    U_in_mag = np.linalg.norm(U_inlet)

    # Velocity deficit: (U_in - u) / U_in
    deficit = 1.0 - U_mag / max(U_in_mag, 1e-9)

    # Wake: cells where local speed < 50% of inlet
    wake_mask       = U_mag < 0.5 * U_in_mag
    recirculation   = U_mag < 0.1 * U_in_mag   # near-zero or reversed

    # Streamwise component (along inlet direction)
    U_in_hat = np.array(U_inlet) / max(U_in_mag, 1e-9)
    U_stream = U_field @ U_in_hat          # (N,) projection onto inlet direction

    return {
        'wake_fraction':        float(wake_mask.sum() / len(U_mag)),
        'recirculation_fraction': float(recirculation.sum() / len(U_mag)),
        'mean_velocity_deficit': float(deficit.mean()),
        'max_velocity_deficit': float(deficit.max()),
        'n_wake_cells':         int(wake_mask.sum()),
        'n_recirculation_cells': int(recirculation.sum()),
        'backflow_fraction':    float((U_stream < 0).sum() / len(U_stream)),
        'interpretation': (
            f"Large wake ({float(wake_mask.sum()/len(U_mag))*100:.0f}% cells) "
            f"with {'strong' if (U_stream < 0).sum() > len(U_stream)*0.02 else 'weak'} recirculation"
        ),
    }


def detect_venturi_acceleration(U_field: np.ndarray,
                                  U_inlet: Tuple[float, float, float]) -> Dict[str, Any]:
    """
    Detect wind acceleration corridors between buildings (Venturi effect).

    Physics: continuity → A₁u₁ = A₂u₂ → u₂ = u₁(A₁/A₂)
    Cells with |u| > 1.2×U_inlet are in accelerated zones.
    """
    U_mag    = np.linalg.norm(U_field, axis=1)
    U_in_mag = np.linalg.norm(U_inlet)

    accel_mask    = U_mag > 1.2 * U_in_mag
    high_accel    = U_mag > 1.5 * U_in_mag

    return {
        'acceleration_fraction':   float(accel_mask.sum() / len(U_mag)),
        'high_acceleration_fraction': float(high_accel.sum() / len(U_mag)),
        'max_velocity':            float(U_mag.max()),
        'max_speed_ratio':         float(U_mag.max() / max(U_in_mag, 1e-9)),
        'interpretation': (
            f"Venturi acceleration: max speed = {U_mag.max():.2f} m/s "
            f"({U_mag.max()/max(U_in_mag,1e-9):.1f}× inlet); "
            f"{float(accel_mask.sum()/len(U_mag))*100:.1f}% cells accelerated"
        ),
    }


def identify_weak_structural_regions(p_field: np.ndarray,
                                      U_field: np.ndarray,
                                      U_inlet: Tuple[float, float, float],
                                      rho: float = config.RHO) -> Dict[str, Any]:
    """
    Identify structurally weak regions based on:
      1. Maximum pressure differential (windward–leeward face Δp)
      2. Peak dynamic pressure on building surfaces
      3. Suction force on roof/leeward faces

    Physics: structural load F = Cp × (0.5 ρ U²) × A
    Peak positive Cp (windward) → compressive load
    Peak negative Cp (leeward/roof) → tensile/suction load
    """
    U_in_mag = np.linalg.norm(U_inlet)
    q_dyn    = 0.5 * rho * U_in_mag ** 2       # dynamic pressure [Pa]
    q_kinem  = 0.5 * U_in_mag ** 2             # kinematic dynamic pressure [m²/s²]

    p_max = float(p_field.max())
    p_min = float(p_field.min())
    delta_p_kinem = p_max - p_min              # peak pressure differential (kinematic)
    delta_p_phys  = delta_p_kinem * rho        # actual pressure differential [Pa]

    # Cp distribution
    p_mean = float(p_field.mean())
    cp_max = (p_max - p_mean) / max(q_kinem, 1e-9)
    cp_min = (p_min - p_mean) / max(q_kinem, 1e-9)

    # Dynamic pressure of local flow
    U_mag = np.linalg.norm(U_field, axis=1)
    q_local_max_kinem = 0.5 * float(U_mag.max()) ** 2
    q_local_max_phys  = q_local_max_kinem * rho

    return {
        'p_differential_kinem':  float(delta_p_kinem),
        'p_differential_Pa':     float(delta_p_phys),
        'Cp_windward_max':       float(cp_max),
        'Cp_leeward_min':        float(cp_min),
        'peak_load_Pa':          float(q_dyn),      # per unit area
        'local_peak_load_Pa':    float(q_local_max_phys),
        'risk_level': (
            'HIGH'   if abs(cp_min) > 1.5 or cp_max > 0.9 else
            'MEDIUM' if abs(cp_min) > 0.8 or cp_max > 0.6 else
            'LOW'
        ),
        'interpretation': (
            f"ΔP = {delta_p_phys:.1f} Pa across building; "
            f"windward Cp = {cp_max:.2f}, leeward Cp = {cp_min:.2f}. "
            f"Peak structural load ≈ {q_dyn:.1f} Pa/m²"
        ),
    }


def analyze_inlet_flow(U_field: np.ndarray,
                        U_inlet: Tuple[float, float, float],
                        n_upstream_cells: int = 2000) -> Dict[str, Any]:
    """
    Analyse inlet/approach flow characteristics.
    Uses first n_upstream_cells cells (lowest cell index → upstream in OpenFOAM).

    Physics: approach flow profile follows ABL power law:
    u(z) / u_ref = (z / z_ref)^α  where α ≈ 0.25 for suburban terrain
    """
    U_in_mag = np.linalg.norm(U_inlet)
    U_sample = U_field[:n_upstream_cells]
    U_mag    = np.linalg.norm(U_sample, axis=1)

    # Uniformity index (how uniform is the approach flow)
    uniformity = 1.0 - float(np.std(U_mag) / max(np.mean(U_mag), 1e-9))

    # Approach flow: fraction within 10% of inlet
    near_inlet  = np.abs(U_mag - U_in_mag) < 0.1 * U_in_mag
    disturbed   = U_mag < 0.9 * U_in_mag

    return {
        'approach_mean_speed':   float(np.mean(U_mag)),
        'approach_uniformity':   float(uniformity),
        'fraction_at_inlet_speed': float(near_inlet.sum() / len(U_mag)),
        'fraction_disturbed':    float(disturbed.sum() / len(U_mag)),
        'interpretation': (
            f"Approach flow: mean {np.mean(U_mag):.2f} m/s "
            f"(target {U_in_mag:.2f} m/s); "
            f"uniformity index {uniformity:.2f}"
        ),
    }


# ────────────────────────────────────────────────────────────────────────────
# Master analysis function
# ────────────────────────────────────────────────────────────────────────────

def full_flow_analysis(p_field:  np.ndarray,
                        U_field:  np.ndarray,
                        U_inlet:  Tuple[float, float, float],
                        rho:      float = config.RHO) -> Dict[str, Any]:
    """
    Run all flow analyses and return a unified report dict.

    This report is passed to the LLM for natural-language interpretation.
    """
    U_in_mag = float(np.linalg.norm(U_inlet))
    U_mag    = np.linalg.norm(U_field, axis=1)

    # Basic field stats
    global_stats = {
        'n_cells':     len(p_field),
        'U_inlet_mag': U_in_mag,
        'U_mean':      float(np.mean(U_mag)),
        'U_max':       float(np.max(U_mag)),
        'U_min':       float(np.min(U_mag)),
        'p_mean':      float(np.mean(p_field)),
        'p_max':       float(np.max(p_field)),
        'p_min':       float(np.min(p_field)),
        'p_range':     float(np.max(p_field) - np.min(p_field)),
    }

    return {
        'global_stats':       global_stats,
        'high_pressure':      detect_high_pressure_zones(p_field, U_in_mag),
        'low_pressure':       detect_low_pressure_zones(p_field, U_in_mag),
        'wake_region':        detect_wake_region(U_field, U_inlet),
        'venturi':            detect_venturi_acceleration(U_field, U_inlet),
        'structural_risk':    identify_weak_structural_regions(p_field, U_field, U_inlet, rho),
        'inlet_flow':         analyze_inlet_flow(U_field, U_inlet),
    }


def format_analysis_for_llm(analysis: Dict[str, Any],
                              case_id: str,
                              inlet: Tuple[float, float, float]) -> str:
    """
    Format analysis dict into a structured prompt section for the LLM.
    """
    gs   = analysis['global_stats']
    hp   = analysis['high_pressure']
    lp   = analysis['low_pressure']
    wake = analysis['wake_region']
    vent = analysis['venturi']
    risk = analysis['structural_risk']
    inf  = analysis['inlet_flow']

    Ux, Uy, Uz = inlet
    lines = [
        f"=== CFD Flow Analysis: {case_id} ===",
        f"",
        f"INLET: ({Ux:.3f}, {Uy:.3f}, {Uz:.3f}) m/s  |  |U| = {gs['U_inlet_mag']:.3f} m/s",
        f"MESH:  {gs['n_cells']:,} cells",
        f"",
        f"── Pressure Field ─────────────────────────────────────",
        f"  Mean / Max / Min  : {gs['p_mean']:.1f} / {gs['p_max']:.1f} / {gs['p_min']:.1f}  [m²/s²]",
        f"  Pressure range    : {gs['p_range']:.1f} m²/s² = {gs['p_range']*config.RHO:.1f} Pa",
        f"  Windward Cp max   : {hp['Cp_max']:.3f}",
        f"  Leeward  Cp min   : {lp['Cp_min']:.3f}",
        f"  High-p fraction   : {hp['fraction_high_p']*100:.1f}%  [{hp['interpretation']}]",
        f"  Low-p  fraction   : {lp['fraction_low_p']*100:.1f}%  [{lp['interpretation']}]",
        f"",
        f"── Velocity Field ─────────────────────────────────────",
        f"  Mean / Max / Min  : {gs['U_mean']:.3f} / {gs['U_max']:.3f} / {gs['U_min']:.3f} m/s",
        f"  Wake fraction     : {wake['wake_fraction']*100:.1f}%  (cells < 50% of U_inlet)",
        f"  Recirculation     : {wake['recirculation_fraction']*100:.1f}%  (cells < 10% of U_inlet)",
        f"  Backflow cells    : {wake['backflow_fraction']*100:.2f}%  ({wake['interpretation']})",
        f"  Venturi effect    : {vent['interpretation']}",
        f"",
        f"── Structural Risk Assessment ──────────────────────────",
        f"  RISK LEVEL        : *** {risk['risk_level']} ***",
        f"  {risk['interpretation']}",
        f"  Windward load     : {risk['Cp_windward_max']:.2f} × {risk['peak_load_Pa']:.1f} Pa/m²",
        f"  Suction load      : {risk['Cp_leeward_min']:.2f} × {risk['peak_load_Pa']:.1f} Pa/m²",
        f"  ΔP across bldg    : {risk['p_differential_Pa']:.1f} Pa",
        f"",
        f"── Approach Flow ───────────────────────────────────────",
        f"  {inf['interpretation']}",
    ]
    return "\n".join(lines)
