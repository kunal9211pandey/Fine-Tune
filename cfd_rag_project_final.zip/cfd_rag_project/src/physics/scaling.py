"""
Physics Engine: Navier-Stokes based field scaling and interpolation.

Core Physics (Incompressible Steady RANS - simpleFoam):
═══════════════════════════════════════════════════════

Governing Equations:
  ∇·u = 0                                              (1) Continuity
  (u·∇)u = -∇(p/ρ) + ∇·[(ν+νt)(∇u + ∇uᵀ)]           (2) Momentum (RANS)
  (u·∇)k  = ∇·[(ν+νt/σk)∇k]  + Pk - ε                (3) k-transport
  (u·∇)ε  = ∇·[(ν+νt/σε)∇ε]  + C1ε(ε/k)Pk - C2ε(ε²/k) (4) ε-transport

Where:
  u   = velocity field [m/s]
  p   = kinematic pressure = P/ρ [m²/s²]
  ν   = kinematic viscosity [m²/s]
  νt  = turbulent viscosity = Cμ k²/ε [m²/s]
  k   = turbulent kinetic energy [m²/s²]
  ε   = turbulent dissipation rate [m²/s³]

Scaling Laws (from dimensional analysis of eqs 1-4):
════════════════════════════════════════════════════

For same geometry, scaling inlet velocity from U₀ → U₁:
  (at similar Re, Cp distribution is conserved)

  u₁  = u₀  × (U₁/U₀)                [velocity: linear]
  p₁  = p₀  × (U₁/U₀)²               [kinematic pressure: quadratic]
  k₁  = k₀  × (U₁/U₀)²               [turbulent KE: quadratic]
  ε₁  = ε₀  × (U₁/U₀)³               [dissipation: cubic]
  νt  = Cμ × k₁²/ε₁  = νt₀×(U₁/U₀)  [turbulent viscosity: linear]

For wind direction change (rotation by matrix R):
  u₁  = R · u₀  × (|U₁|/|U₀|)
  p₁  ≈ p₀ × (|U₁|/|U₀|)²   [approximate for small Δθ]

For different geometry with similarity score s ∈ [0,1]:
  Use weighted blending of top-k matched cases' fields.
"""
import numpy as np
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional
import config


# ────────────────────────────────────────────────────────────────────────────
# Rotation utilities
# ────────────────────────────────────────────────────────────────────────────

def rotation_matrix_from_vectors(v_from: np.ndarray,
                                  v_to:   np.ndarray) -> np.ndarray:
    """
    Compute 3×3 rotation matrix that rotates unit vector v_from → v_to.
    Uses Rodrigues' rotation formula.

    R = I + [k]× + [k]×² × (1 - cosθ)/sinθ²
    where k = (v_from × v_to) / |v_from × v_to|
    """
    a = v_from / (np.linalg.norm(v_from) + 1e-15)
    b = v_to   / (np.linalg.norm(v_to)   + 1e-15)

    cross = np.cross(a, b)
    dot   = np.clip(np.dot(a, b), -1.0, 1.0)
    sin_t = np.linalg.norm(cross)

    if sin_t < 1e-9:
        # Parallel or anti-parallel
        if dot > 0:
            return np.eye(3)
        else:
            # 180° rotation – find orthogonal axis
            orth = np.array([1, 0, 0]) if abs(a[0]) < 0.9 else np.array([0, 1, 0])
            k = np.cross(a, orth)
            k /= np.linalg.norm(k) + 1e-15
            return 2.0 * np.outer(k, k) - np.eye(3)

    # Skew-symmetric cross-product matrix
    K = np.array([
        [ 0,       -cross[2],  cross[1]],
        [ cross[2],  0,       -cross[0]],
        [-cross[1],  cross[0],  0      ],
    ])
    R = np.eye(3) + K + K @ K * ((1.0 - dot) / (sin_t ** 2))
    return R


# ────────────────────────────────────────────────────────────────────────────
# Core field scaling (same geometry, different inlet)
# ────────────────────────────────────────────────────────────────────────────

def scale_velocity_field(U_field: np.ndarray,
                          U_ref:   Tuple[float, float, float],
                          U_new:   Tuple[float, float, float]) -> np.ndarray:
    """
    Scale velocity field from reference inlet U_ref to new inlet U_new.

    Physics: u_new = R · u_ref × (|U_new| / |U_ref|)
      - Magnitude ratio captures the linear scaling
      - Rotation matrix R accounts for wind direction change

    Parameters
    ----------
    U_field : np.ndarray (N, 3)  – reference velocity vectors
    U_ref   : (Ux, Uy, Uz) reference inlet velocity
    U_new   : (Ux, Uy, Uz) new inlet velocity

    Returns
    -------
    np.ndarray (N, 3) – scaled velocity field
    """
    U_ref_arr = np.array(U_ref, dtype=np.float64)
    U_new_arr = np.array(U_new, dtype=np.float64)

    mag_ref = np.linalg.norm(U_ref_arr)
    mag_new = np.linalg.norm(U_new_arr)

    if mag_ref < 1e-9:
        return U_field.copy()

    # Magnitude ratio
    mag_ratio = mag_new / mag_ref

    # Direction rotation
    R = rotation_matrix_from_vectors(U_ref_arr, U_new_arr)

    # Apply: rotate then scale
    # (N,3) @ (3,3).T  →  (N,3)
    U_scaled = (U_field @ R.T) * mag_ratio

    return U_scaled


def scale_pressure_field(p_field: np.ndarray,
                          U_ref:   Tuple[float, float, float],
                          U_new:   Tuple[float, float, float]) -> np.ndarray:
    """
    Scale kinematic pressure field (p = P/ρ) from U_ref → U_new.

    Physics: Pressure coefficient Cp = (p - p_∞) / (0.5 U²)
    For same geometry+direction:  Cp is constant
    ∴ p_new = p_ref × (|U_new| / |U_ref|)²

    For direction changes, the stagnation point moves but we apply an
    approximate correction via |U|² ratio.
    """
    mag_ref = np.linalg.norm(U_ref)
    mag_new = np.linalg.norm(U_new)

    if mag_ref < 1e-9:
        return p_field.copy()

    ratio_sq = (mag_new / mag_ref) ** 2
    return p_field * ratio_sq


def scale_k_field(k_field: np.ndarray,
                   U_ref:   Tuple[float, float, float],
                   U_new:   Tuple[float, float, float]) -> np.ndarray:
    """Scale turbulent kinetic energy: k_new = k_ref × (|U_new|/|U_ref|)²"""
    mag_ref = np.linalg.norm(U_ref)
    mag_new = np.linalg.norm(U_new)
    if mag_ref < 1e-9:
        return k_field.copy()
    return k_field * (mag_new / mag_ref) ** 2


def scale_epsilon_field(e_field: np.ndarray,
                         U_ref:   Tuple[float, float, float],
                         U_new:   Tuple[float, float, float]) -> np.ndarray:
    """Scale dissipation rate: ε_new = ε_ref × (|U_new|/|U_ref|)³"""
    mag_ref = np.linalg.norm(U_ref)
    mag_new = np.linalg.norm(U_new)
    if mag_ref < 1e-9:
        return e_field.copy()
    return e_field * (mag_new / mag_ref) ** 3


# ────────────────────────────────────────────────────────────────────────────
# Multi-case weighted interpolation (for different geometries)
# ────────────────────────────────────────────────────────────────────────────

def compute_interpolation_weights(similarities: List[float],
                                   sharpness: float = 4.0) -> np.ndarray:
    """
    Compute interpolation weights from similarity scores.

    Uses exponential sharpening: w_i = exp(sharpness × s_i) / Σexp(...)
    Higher sharpness → closer to nearest-neighbour (1 winner takes all).
    Lower sharpness  → smoother blending.

    Physics rationale: for very similar cases (s>0.9), blending adds noise;
    for diverse cases (s≈0.5), blending provides better coverage.
    """
    s = np.array(similarities, dtype=np.float64)
    # Adaptive sharpness: high when best match is very similar
    if s[0] > 0.85:
        sharpness = 8.0   # best match dominates
    elif s[0] > 0.70:
        sharpness = 4.0   # moderate blending
    else:
        sharpness = 2.0   # spread the uncertainty

    log_w = sharpness * s
    log_w -= log_w.max()    # numerical stability
    w = np.exp(log_w)
    return w / w.sum()


def blend_scalar_fields(fields: List[np.ndarray],
                         weights: np.ndarray) -> np.ndarray:
    """
    Weighted average of scalar fields.
    Handles fields of different sizes by interpolating to the first field's size.
    """
    target_size = len(fields[0])
    blended = np.zeros(target_size, dtype=np.float64)
    for field, w in zip(fields, weights):
        if len(field) != target_size:
            # Resample via linear interpolation
            x_src = np.linspace(0, 1, len(field))
            x_tgt = np.linspace(0, 1, target_size)
            field = np.interp(x_tgt, x_src, field)
        blended += w * field
    return blended


def blend_vector_fields(fields: List[np.ndarray],
                         weights: np.ndarray) -> np.ndarray:
    """
    Weighted average of vector fields (N, 3).
    """
    target_size = fields[0].shape[0]
    blended = np.zeros((target_size, 3), dtype=np.float64)
    for field, w in zip(fields, weights):
        if field.shape[0] != target_size:
            # Resample each component
            x_src = np.linspace(0, 1, field.shape[0])
            x_tgt = np.linspace(0, 1, target_size)
            resampled = np.column_stack([
                np.interp(x_tgt, x_src, field[:, c]) for c in range(3)
            ])
            field = resampled
        blended += w * field
    return blended


# ────────────────────────────────────────────────────────────────────────────
# Boundary condition generator
# ────────────────────────────────────────────────────────────────────────────

def compute_inlet_turbulence(U_mag: float, L_ref: float,
                              I: float = config.TURBULENCE_INTENSITY) -> Tuple[float, float]:
    """
    Compute k and ε at inlet using standard ABL turbulence correlations.

    k = (3/2)(I·U)²
    ε = Cμ^(3/4) · k^(3/2) / L

    where L = characteristic turbulent length scale ≈ 0.07 × H_building

    Parameters
    ----------
    U_mag : inlet wind speed [m/s]
    L_ref : reference length (building height) [m]
    I     : turbulence intensity (fraction, e.g. 0.10)

    Returns
    -------
    (k_inlet, epsilon_inlet) in SI units
    """
    k  = 1.5 * (I * U_mag) ** 2
    L  = max(L_ref, 1.0)
    ep = (config.CMU ** 0.75) * (k ** 1.5) / L
    return float(k), float(ep)


def compute_turbulent_viscosity(k: np.ndarray,
                                 epsilon: np.ndarray) -> np.ndarray:
    """
    Compute turbulent kinematic viscosity: νt = Cμ k²/ε  [m²/s]
    """
    denom = np.where(np.abs(epsilon) > 1e-15, epsilon, 1e-15)
    return config.CMU * k**2 / denom


# ────────────────────────────────────────────────────────────────────────────
# Pressure coefficient (non-dimensional)
# ────────────────────────────────────────────────────────────────────────────

def compute_cp(p_field: np.ndarray, U_inlet_mag: float,
                p_reference: float = 0.0,
                rho: float = config.RHO) -> np.ndarray:
    """
    Compute pressure coefficient: Cp = (p - p_ref) / (0.5 ρ U²)

    NOTE: p here is kinematic pressure (p/ρ in OpenFOAM),
    so dynamic pressure q = 0.5 * U² (already divided by ρ).

    Cp = (p_kinem - p_ref_kinem) / (0.5 × U_inlet²)
    """
    q_dyn = 0.5 * U_inlet_mag ** 2
    if q_dyn < 1e-9:
        return np.zeros_like(p_field)
    return (p_field - p_reference) / q_dyn


# ────────────────────────────────────────────────────────────────────────────
# Wind angle (azimuth) computation
# ────────────────────────────────────────────────────────────────────────────

def inlet_to_azimuth(Ux: float, Uy: float) -> float:
    """Return azimuth in degrees: 0°=+X(East), 90°=+Y(North), etc."""
    return float(np.degrees(np.arctan2(Uy, Ux)))


def angular_difference(a1_deg: float, a2_deg: float) -> float:
    """Smallest angle between two azimuths [0, 180]."""
    diff = abs(a1_deg - a2_deg) % 360.0
    return min(diff, 360.0 - diff)
