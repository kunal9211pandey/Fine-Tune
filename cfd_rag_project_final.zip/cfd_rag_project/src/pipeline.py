"""
pipeline.py  —  Physics-Based CFD RAG Pipeline.
PURE PREDICTION ENGINE. No Q&A. No chatbot. No interactive mode.

Input  → (inlet_velocity, buildings.obj)
Output → OpenFOAM p + U fields  +  JSON/TXT report
"""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

import numpy as np
from rich.console import Console
from rich.panel   import Panel
from rich.table   import Table
from rich         import box

import config
from src.features.extractor  import extract_query_features
from src.vector_db.store     import CFDVectorStore
from src.parsers.foam_parser import (
    read_full_p_field, read_full_U_field,
    write_foam_scalar_field, write_foam_vector_field,
    write_foam_bc_U, write_foam_bc_p,
)
from src.physics.scaling import (
    scale_velocity_field, scale_pressure_field,
    scale_k_field, scale_epsilon_field,
    blend_scalar_fields, blend_vector_fields,
    compute_inlet_turbulence,
)
from src.physics.analyzer import full_flow_analysis, format_analysis_for_llm
from src.llm.agent        import GroqCFDAgent

console = Console()


class CFDRagPipeline:
    """
    Physics-Based RAG for CFD field prediction.
    Single public method: predict()
    """

    def __init__(self,
                 db_path:    Optional[Path] = None,
                 output_dir: Optional[Path] = None,
                 top_k:      int  = config.TOP_K_MATCHES,
                 use_llm:    bool = True):
        self.store      = CFDVectorStore(db_path)
        self.output_dir = Path(output_dir or config.OUTPUT_DIR)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.top_k   = top_k
        self.use_llm = use_llm
        self._llm    = GroqCFDAgent() if use_llm else None

    # ─────────────────────────────────────────────────────────────────────
    def predict(self,
                inlet_velocity: Tuple[float, float, float],
                obj_path:       Path,
                case_name:      str            = "predicted_case",
                system_dir:     Optional[Path] = None) -> Dict[str, Any]:
        """
        Full end-to-end prediction:
          inlet + OBJ  →  4000/p, 4000/U, 0/BC files, reports
        """
        t0 = time.time()
        console.rule("[bold cyan]CFD Physics RAG  —  Prediction Engine")

        # ── 1. Feature extraction ─────────────────────────────────────────
        console.print("[bold]Step 1/10[/]  Extracting physics features …")
        q      = extract_query_features(Path(obj_path), inlet_velocity, system_dir)
        q_feat = q["features"]
        q_raw  = q["raw"]
        q_vec  = q["feature_vec"]
        _show_query(q_feat, inlet_velocity)

        # ── 2. Vector DB retrieval ────────────────────────────────────────
        n_db = self.store.count()
        if n_db == 0:
            raise RuntimeError("Vector DB empty – run  python index_cases.py  first.")
        console.print(f"[bold]Step 2/10[/]  Vector DB query  ({n_db} cases, top-{self.top_k}) …")
        candidates = self.store.query(q_vec, top_k=self.top_k)
        _show_candidates(candidates)

        # ── 3. LLM physics-based case ranking ────────────────────────────
        console.print("[bold]Step 3/10[/]  LLM case ranking …")
        if self.use_llm:
            selection = self._llm.rank_and_select(q_feat, q_raw, candidates)
        else:
            selection = _nn_selection(candidates)
        _show_selection(selection)

        # ── 4. Read matched OpenFOAM fields ───────────────────────────────
        console.print("[bold]Step 4/10[/]  Reading converged fields from matched cases …")
        cand_map = {c["id"]: c for c in candidates}
        p_list, U_list, k_list, e_list, wts = [], [], [], [], []
        ref_hdr_p = ref_ftr_p = ref_hdr_U = ref_ftr_U = None
        best_dir: Optional[Path] = None

        for sel in selection["selected_cases"]:
            cid  = sel["id"]
            cand = cand_map.get(cid, candidates[0])
            cdir = Path(cand["case_dir"])
            U_ref = tuple(cand["inlet_velocity"])

            p_path = cdir / str(config.CONVERGENCE_TIME) / "p"
            U_path = cdir / str(config.CONVERGENCE_TIME) / "U"
            if not p_path.exists() or not U_path.exists():
                console.print(f"  [yellow]Skip {cid}[/] – fields missing")
                continue

            console.print(f"  Reading  {cid}  (w={sel['weight']:.3f})")
            pv, hdrp, ftrp = read_full_p_field(p_path)
            Uv, hdrU, ftrU = read_full_U_field(U_path)

            if ref_hdr_p is None:
                ref_hdr_p, ref_ftr_p = hdrp, ftrp
                ref_hdr_U, ref_ftr_U = hdrU, ftrU
                best_dir = cdir

            # ── 5. Navier-Stokes field scaling ────────────────────────────
            p_list.append(scale_pressure_field(pv, U_ref, inlet_velocity))
            U_list.append(scale_velocity_field(Uv, U_ref, inlet_velocity))
            wts.append(float(sel["weight"]))

            # k and ε (optional)
            kp = cdir / str(config.CONVERGENCE_TIME) / "k"
            ep = cdir / str(config.CONVERGENCE_TIME) / "epsilon"
            if kp.exists() and ep.exists():
                try:
                    kv, hk, fk = read_full_p_field(kp)
                    ev, he, fe = read_full_p_field(ep)
                    k_list.append((scale_k_field(kv, U_ref, inlet_velocity),       hk, fk))
                    e_list.append((scale_epsilon_field(ev, U_ref, inlet_velocity),  he, fe))
                except Exception:
                    pass

        if not p_list:
            raise RuntimeError("No matched case fields available.")
        console.print(f"[bold]Step 5/10[/]  NS scaling done for {len(p_list)} case(s)")

        # ── 6. Weighted field blending ────────────────────────────────────
        console.print("[bold]Step 6/10[/]  Weighted field blending …")
        w = np.array(wts, dtype=np.float64)
        w /= w.sum()
        if len(p_list) == 1:
            p_final, U_final = p_list[0], U_list[0]
            console.print("  Single best match – no blending")
        else:
            console.print(f"  Blending {len(p_list)} cases  w={np.round(w,3)}")
            p_final = blend_scalar_fields(p_list, w)
            U_final = blend_vector_fields(U_list, w)

        # ── 7. Flow field analysis ────────────────────────────────────────
        console.print("[bold]Step 7/10[/]  Physics flow analysis …")
        N   = min(20_000, len(p_final))
        idx = np.random.default_rng(42).choice(len(p_final), N, replace=False)
        analysis = full_flow_analysis(p_final[idx], U_final[idx], inlet_velocity)
        atxt     = format_analysis_for_llm(analysis, case_name, inlet_velocity)
        console.print(Panel(atxt, title="Flow Analysis", border_style="green", padding=(0,1)))

        # ── 8. LLM physics validation + orientation ───────────────────────
        console.print("[bold]Step 8/10[/]  Physics validation + orientation …")
        Umag_arr = np.linalg.norm(U_final[idx], axis=1)
        pstats = dict(p_mean=float(p_final[idx].mean()), p_max=float(p_final[idx].max()),
                      p_min=float(p_final[idx].min()),   p_std=float(p_final[idx].std()))
        Ustats = dict(U_mag_mean=float(Umag_arr.mean()), U_mag_max=float(Umag_arr.max()),
                      U_mag_min=float(Umag_arr.min()),   U_mag_std=float(Umag_arr.std()))

        if self.use_llm:
            validation   = self._llm.validate_field_statistics(
                pstats, Ustats, inlet_velocity, q_raw.get("L_ref", 60.0))
            orientation  = self._llm.compute_optimal_orientation(
                analysis, q_raw["geom_features"], inlet_velocity)
        else:
            validation  = _physics_validate(pstats, Ustats, inlet_velocity)
            orientation = _physics_orientation(analysis, inlet_velocity)
        _show_validation(validation)

        # ── 9. Write OpenFOAM output files ────────────────────────────────
        console.print("[bold]Step 9/10[/]  Writing OpenFOAM files …")
        out_case = _write_foam_files(
            case_name, self.output_dir, p_final, U_final,
            ref_hdr_p, ref_ftr_p, ref_hdr_U, ref_ftr_U,
            k_list, e_list, w, inlet_velocity, best_dir,
            q_raw.get("L_ref", 60.0))

        # ── 10. Reports ───────────────────────────────────────────────────
        console.print("[bold]Step 10/10[/]  Writing reports …")
        result = _assemble_result(
            case_name, inlet_velocity, obj_path, out_case,
            q_feat, candidates, selection,
            analysis, atxt, pstats, Ustats,
            validation, orientation, time.time() - t0)
        _save_reports(out_case, result, atxt)

        console.rule("[bold green]Done")
        console.print(f"  [cyan]{out_case}/{config.CONVERGENCE_TIME}/p[/]  ← pressure")
        console.print(f"  [cyan]{out_case}/{config.CONVERGENCE_TIME}/U[/]  ← velocity")
        console.print(f"  [cyan]{out_case}/0/[/]  ← boundary conditions")
        console.print(f"  [cyan]{out_case}/prediction_report.txt[/]")
        console.print(f"  Elapsed: {time.time()-t0:.1f}s")
        return result


# ─────────────────────────────────────────────────────────────────────────────
# File writer
# ─────────────────────────────────────────────────────────────────────────────

def _write_foam_files(
        case_name, output_dir, p_final, U_final,
        hdrp, ftrp, hdrU, ftrU,
        k_list, e_list, w, inlet_velocity, best_dir, L_ref) -> Path:

    out  = Path(output_dir) / case_name
    t    = out / str(config.CONVERGENCE_TIME)
    bc   = out / "0"
    t.mkdir(parents=True, exist_ok=True)
    bc.mkdir(parents=True, exist_ok=True)

    write_foam_scalar_field(t / "p", p_final, hdrp, ftrp)
    write_foam_vector_field(t / "U", U_final, hdrU, ftrU)
    console.print(f"  [green]✓[/] {config.CONVERGENCE_TIME}/p  ({len(p_final):,} cells)")
    console.print(f"  [green]✓[/] {config.CONVERGENCE_TIME}/U  ({len(U_final):,} cells)")

    if k_list and e_list:
        ww = w[:len(k_list)]; ww /= ww.sum()
        k_f = blend_scalar_fields([t[0] for t in k_list], ww)
        e_f = blend_scalar_fields([t[0] for t in e_list], ww)
        write_foam_scalar_field(t / "k",      k_f, k_list[0][1], k_list[0][2])
        write_foam_scalar_field(t / "epsilon", e_f, e_list[0][1], e_list[0][2])
        console.print(f"  [green]✓[/] {config.CONVERGENCE_TIME}/k, {config.CONVERGENCE_TIME}/epsilon")

    Umag  = float(np.linalg.norm(inlet_velocity))
    k_in, ep_in = compute_inlet_turbulence(Umag, L_ref)
    write_foam_bc_U(bc / "U", inlet_velocity, k_in, ep_in)
    write_foam_bc_p(bc / "p")
    console.print(f"  [green]✓[/] 0/U  0/p  (k_in={k_in:.3e}, ε_in={ep_in:.3e})")

    if best_dir:
        for fn in ("k", "epsilon", "nut"):
            s = best_dir / "0" / fn
            if s.exists():
                shutil.copy2(s, bc / fn)
        for sub in ("system", "constant"):
            src = best_dir / sub
            dst = out / sub
            if src.exists() and not dst.exists():
                ig = shutil.ignore_patterns("polyMesh") if sub == "constant" else None
                shutil.copytree(src, dst, ignore=ig)
        console.print(f"  [green]✓[/] system/  constant/  (from best match)")
    return out


# ─────────────────────────────────────────────────────────────────────────────
# Result + report builders
# ─────────────────────────────────────────────────────────────────────────────

def _assemble_result(case_name, inlet_velocity, obj_path, out_case,
                      q_feat, candidates, selection, analysis, atxt,
                      pstats, Ustats, validation, orientation, elapsed):
    def _f(v):
        if isinstance(v, (np.floating, np.integer)): return float(v)
        if isinstance(v, np.ndarray): return v.tolist()
        return v
    def _fd(d): return {k: _f(v) for k, v in d.items()}

    risk = analysis["structural_risk"]
    return {
        "case_name":        case_name,
        "inlet_velocity":   list(inlet_velocity),
        "obj_path":         str(obj_path),
        "output_dir":       str(out_case),
        "elapsed_sec":      round(elapsed, 2),
        "db_matches":       [{"id": c["id"], "similarity": round(c["similarity"],4),
                              "inlet": list(c["inlet_velocity"])} for c in candidates],
        "llm_selection":    selection,
        "flow_analysis":    {k: (_fd(v) if isinstance(v, dict) else v)
                              for k, v in analysis.items()},
        "predicted_field_stats": {**_fd(pstats), **_fd(Ustats)},
        "physics_validation":    validation,
        "orientation_recommendation": orientation,
        "key_physics": {
            "Re_building":       round(q_feat.get("Re_building",0), 2),
            "inlet_magnitude":   round(q_feat.get("inlet_magnitude",0), 4),
            "inlet_azimuth_deg": round(q_feat.get("inlet_azimuth_deg",0), 2),
            "Cp_windward_max":   round(risk["Cp_windward_max"], 4),
            "Cp_leeward_min":    round(risk["Cp_leeward_min"], 4),
            "delta_p_Pa":        round(risk["p_differential_Pa"], 2),
            "risk_level":        risk["risk_level"],
            "wake_fraction_pct": round(analysis["wake_region"]["wake_fraction"]*100, 2),
            "max_speed_ratio":   round(analysis["venturi"]["max_speed_ratio"], 4),
        },
    }


def _save_reports(out_case: Path, result: dict, atxt: str):
    # JSON
    jp = out_case / "prediction_report.json"
    with open(jp, "w") as f:
        json.dump(result, f, indent=2, default=str)

    sel = result["llm_selection"]
    val = result["physics_validation"]
    kp  = result["key_physics"]
    ps  = result["predicted_field_stats"]
    ori = result["orientation_recommendation"]

    lines = [
        "="*72,
        "  CFD PHYSICS-BASED RAG  —  PREDICTION REPORT",
        f"  Case    : {result['case_name']}",
        f"  Inlet   : {result['inlet_velocity']}  m/s",
        f"  OBJ     : {result['obj_path']}",
        f"  Elapsed : {result['elapsed_sec']}s",
        "="*72, "",
        "── 1.  VECTOR DB MATCHES ──────────────────────────────────────────",
    ]
    for i, m in enumerate(result["db_matches"]):
        lines.append(f"  [{i+1}] {m['id']:<45}  sim={m['similarity']:.4f}  inlet={m['inlet']}")
    lines += ["",
        "── 2.  LLM SELECTION ──────────────────────────────────────────────",
        f"  Best match   : {sel.get('best_case_id','')}",
        f"  Strategy     : {sel.get('blend_strategy','')}",
        f"  Speed scale  : ×{sel.get('magnitude_scaling_ratio',1):.4f}",
        f"  Reasoning    : {sel.get('reasoning','')}",
        "", "── 3.  KEY PHYSICS SCALARS ────────────────────────────────────────",
        f"  Re_building      = {kp['Re_building']:.3e}",
        f"  |U_inlet|        = {kp['inlet_magnitude']:.4f}  m/s",
        f"  Wind azimuth     = {kp['inlet_azimuth_deg']:.2f}°",
        f"  Cp windward max  = {kp['Cp_windward_max']:.4f}",
        f"  Cp leeward min   = {kp['Cp_leeward_min']:.4f}",
        f"  ΔP across bldg   = {kp['delta_p_Pa']:.2f}  Pa",
        f"  Structural risk  = {kp['risk_level']}",
        f"  Wake fraction    = {kp['wake_fraction_pct']:.2f}%",
        f"  Max speed ratio  = {kp['max_speed_ratio']:.4f}×",
        "", "── 4.  PREDICTED FIELD STATISTICS ─────────────────────────────────",
        f"  p (m²/s²) : mean={ps['p_mean']:.4f}  max={ps['p_max']:.4f}  min={ps['p_min']:.4f}  std={ps['p_std']:.4f}",
        f"  U (m/s)   : mean={ps['U_mag_mean']:.4f}  max={ps['U_mag_max']:.4f}  min={ps['U_mag_min']:.4f}  std={ps['U_mag_std']:.4f}",
        "", "── 5.  FULL FLOW ANALYSIS ──────────────────────────────────────────",
        atxt,
        "", "── 6.  PHYSICS VALIDATION ─────────────────────────────────────────",
        f"  Verdict    : {val.get('verdict','')}",
        f"  Confidence : {val.get('confidence','')}",
        f"  Valid      : {val.get('is_physically_valid','')}",
    ]
    for w in val.get("warnings", []):
        lines.append(f"  ⚠  {w}")
    lines += ["",
        "── 7.  OPTIMAL ORIENTATION RECOMMENDATION ─────────────────────────",
        ori,
        "", "── 8.  OUTPUT FILES ────────────────────────────────────────────────",
        f"  {result['output_dir']}/{config.CONVERGENCE_TIME}/p",
        f"  {result['output_dir']}/{config.CONVERGENCE_TIME}/U",
        f"  {result['output_dir']}/0/U  0/p  0/k  0/epsilon  0/nut",
        f"  {result['output_dir']}/system/",
        f"  {result['output_dir']}/constant/",
        "="*72,
    ]
    tp = out_case / "prediction_report.txt"
    tp.write_text("\n".join(lines), encoding="utf-8")
    console.print(f"  [green]✓[/] {jp.name}  {tp.name}")


# ─────────────────────────────────────────────────────────────────────────────
# Rich helpers
# ─────────────────────────────────────────────────────────────────────────────

def _show_query(f, inlet):
    Ux, Uy, Uz = inlet
    console.print(Panel(
        f"Inlet  ({Ux:.3f},{Uy:.3f},{Uz:.3f}) m/s   "
        f"|U|={f['inlet_magnitude']:.3f}   azimuth={f['inlet_azimuth_deg']:.1f}°\n"
        f"Re={f['Re_building']:.3e}   H_bldg={f['geom_max_height']:.1f}m   "
        f"footprint={f['geom_footprint_area']:.0f}m²   vol={f['geom_volume']:.0f}m³\n"
        f"k_in={f['k_inlet']:.3e}   ε_in={f['epsilon_inlet']:.3e}   I={f['turbulence_intensity']*100:.1f}%",
        title="Query", border_style="cyan"))


def _show_candidates(cands):
    t = Table(title="Retrieved Cases", box=box.SIMPLE_HEAVY)
    for col, j in [("#","r"),("Case ID","l"),("Sim","r"),("Inlet","r"),
                   ("|U|","r"),("Azi°","r"),("H m","r"),("Re","r")]:
        t.add_column(col, justify=j)
    for i, c in enumerate(cands):
        m = c["metadata"]
        t.add_row(str(i+1), c["id"][:45], f"{c['similarity']:.4f}",
            f"({m.get('inlet_Ux',0):.2f},{m.get('inlet_Uy',0):.2f},{m.get('inlet_Uz',0):.2f})",
            f"{m.get('inlet_magnitude',0):.3f}", f"{m.get('inlet_azimuth_deg',0):.1f}",
            f"{m.get('geom_max_height',0):.1f}", f"{m.get('Re_building',0):.2e}")
    console.print(t)


def _show_selection(sel):
    s = "  ".join(f"{s['id']} w={s['weight']:.3f}" for s in sel["selected_cases"])
    console.print(Panel(
        f"Best: {sel.get('best_case_id','')}   strategy={sel.get('blend_strategy','')}   "
        f"scale=×{sel.get('magnitude_scaling_ratio',1):.4f}\n"
        f"Selected: {s}\n{sel.get('reasoning','')}",
        title="LLM Selection", border_style="yellow"))


def _show_validation(v):
    c = "green" if v.get("is_physically_valid") else "red"
    console.print(f"  [{c}]{v.get('verdict','')}[/]  (conf={v.get('confidence','')})")
    for w in v.get("warnings", []):
        console.print(f"  [yellow]  ⚠  {w}[/]")


# ─────────────────────────────────────────────────────────────────────────────
# no-LLM fallbacks
# ─────────────────────────────────────────────────────────────────────────────

def _nn_selection(candidates):
    return {"best_case_id": candidates[0]["id"],
            "selected_cases": [{"id": candidates[0]["id"], "weight": 1.0}],
            "blend_strategy": "nearest_neighbour",
            "magnitude_scaling_ratio": 1.0,
            "azimuth_correction_needed": False,
            "geometry_similarity_concern": "unknown",
            "reasoning": "Nearest-neighbour (LLM disabled)."}


def _physics_validate(ps, Us, inlet):
    q = 0.5 * float(np.linalg.norm(inlet))**2 + 1e-9
    cp_max  = (ps["p_max"] - ps["p_mean"]) / q
    cp_min  = (ps["p_min"] - ps["p_mean"]) / q
    ur      = Us["U_mag_max"] / max(float(np.linalg.norm(inlet)), 1e-9)
    warns   = ([f"Cp_max={cp_max:.2f}>1"] if cp_max > 1.05 else []) + \
              ([f"Cp_min={cp_min:.2f}<-3.5"] if cp_min < -3.5 else []) + \
              ([f"U_max_ratio={ur:.2f}>4"] if ur > 4 else [])
    ok = len(warns) == 0
    return {"Cp_max_actual": round(cp_max,4), "Cp_min_actual": round(cp_min,4),
            "U_max_ratio": round(ur,4),
            "U_mean_ratio": round(Us["U_mag_mean"]/max(float(np.linalg.norm(inlet)),1e-9),4),
            "is_physically_valid": ok, "warnings": warns,
            "confidence": "medium" if ok else "low",
            "verdict": "Fields physically consistent." if ok else f"Issues: {'; '.join(warns)}"}


def _physics_orientation(analysis, inlet):
    azi  = float(np.degrees(np.arctan2(inlet[1], inlet[0])))
    risk = analysis["structural_risk"]
    return (f"Current azimuth {azi:.1f}°. Risk={risk['risk_level']}. "
            f"ΔP={risk['p_differential_Pa']:.1f} Pa. "
            "Rotate 45° (corner-on) to reduce Cp_windward by ~15%. "
            "Align long axis parallel to wind for minimum drag (streamlined orientation).")
