"""
ChromaDB-backed vector store for CFD case embeddings.

Each document in ChromaDB represents one CFD case:
  - ID      : case name (e.g. "dublin_Spring_building4")
  - embedding : physics feature vector (33-dim)
  - metadata  : all features as JSON strings + case path
  - document  : human-readable case summary for LLM context

The store uses cosine distance for physics feature similarity
(inlet velocity direction + geometry shape matter more than scale).
"""
import json
import numpy as np
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

import chromadb
from chromadb.config import Settings

import config


COLLECTION_NAME = "cfd_building_cases"


class CFDVectorStore:
    """
    Thin wrapper around ChromaDB for CFD case retrieval.
    """

    def __init__(self, db_path: Optional[Path] = None):
        db_path = Path(db_path or config.CHROMA_DB_PATH)
        db_path.mkdir(parents=True, exist_ok=True)

        self._client = chromadb.PersistentClient(
            path=str(db_path),
            settings=Settings(anonymized_telemetry=False),
        )
        self._col = self._client.get_or_create_collection(
            name=COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},   # cosine similarity
        )

    # ────────────────────────────────────────────────────────────────────────
    # Normalisation helpers (fit/transform on all indexed cases)
    # ────────────────────────────────────────────────────────────────────────

    def fit_normaliser(self, all_vectors: List[np.ndarray]) -> None:
        """
        Compute and store per-feature mean/std for normalisation.
        Call once after indexing all cases.
        """
        mat = np.stack(all_vectors, axis=0)          # (N_cases, F_dim)
        mu    = mat.mean(axis=0)
        sigma = mat.std(axis=0)
        self._client.get_or_create_collection("_normaliser").upsert(
            ids=["stats"],
            embeddings=[mu.tolist()],
            metadatas=[{"sigma": json.dumps(sigma.tolist()),
                        "mu":    json.dumps(mu.tolist())}],
        )

    def get_normaliser(self) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        """Return (mu, sigma) or (None, None) if not yet computed."""
        try:
            col = self._client.get_collection("_normaliser")
            res = col.get(ids=["stats"], include=["metadatas", "embeddings"])
            mu    = np.array(json.loads(res['metadatas'][0]['mu']))
            sigma = np.array(json.loads(res['metadatas'][0]['sigma']))
            return mu, sigma
        except Exception:
            return None, None

    def normalise(self, vec: np.ndarray) -> np.ndarray:
        mu, sigma = self.get_normaliser()
        if mu is None:
            return vec
        return (vec - mu) / np.where(sigma > 1e-9, sigma, 1.0)

    # ────────────────────────────────────────────────────────────────────────
    # Indexing
    # ────────────────────────────────────────────────────────────────────────

    def add_case(self,
                 case_id: str,
                 feature_vec: np.ndarray,
                 features: Dict[str, float],
                 raw: Dict[str, Any],
                 document_text: str) -> None:
        """
        Add or update a CFD case in the vector store.

        Parameters
        ----------
        case_id      : unique identifier (e.g. "dublin_Spring_building4")
        feature_vec  : raw (unnormalised) feature vector
        features     : full feature dict (for metadata)
        raw          : raw parsed data (paths, inlet velocity, etc.)
        document_text: human-readable summary for LLM context
        """
        # Normalise before storing
        norm_vec = self.normalise(feature_vec)

        # Flatten metadata (ChromaDB only supports str/int/float/bool)
        meta = {}
        for k, v in features.items():
            meta[k] = float(v) if not np.isnan(float(v)) else 0.0
        meta['case_dir']      = str(raw.get('case_dir', ''))
        meta['obj_path']      = str(raw.get('obj_path', ''))
        meta['inlet_Ux']      = float(raw['inlet_velocity'][0])
        meta['inlet_Uy']      = float(raw['inlet_velocity'][1])
        meta['inlet_Uz']      = float(raw['inlet_velocity'][2])
        meta['k_inlet']       = float(raw.get('k_inlet', 0))
        meta['epsilon_inlet'] = float(raw.get('epsilon_inlet', 0))

        self._col.upsert(
            ids=[case_id],
            embeddings=[norm_vec.tolist()],
            metadatas=[meta],
            documents=[document_text],
        )

    def count(self) -> int:
        return self._col.count()

    def list_cases(self) -> List[str]:
        return self._col.get(include=[])['ids']

    # ────────────────────────────────────────────────────────────────────────
    # Retrieval
    # ────────────────────────────────────────────────────────────────────────

    def query(self,
              query_vec: np.ndarray,
              top_k: int = config.TOP_K_MATCHES,
              where_filter: Optional[dict] = None) -> List[Dict[str, Any]]:
        """
        Find the top-k most similar cases.

        Returns
        -------
        List of dicts with keys:
          id, distance, metadata, document, similarity_score
        """
        norm_vec = self.normalise(query_vec)

        kwargs = dict(
            query_embeddings=[norm_vec.tolist()],
            n_results=min(top_k, self.count()),
            include=['metadatas', 'documents', 'distances'],
        )
        if where_filter:
            kwargs['where'] = where_filter

        res = self._col.query(**kwargs)

        results = []
        for i in range(len(res['ids'][0])):
            dist = res['distances'][0][i]
            # ChromaDB cosine distance ∈ [0, 2]; convert to similarity [0, 1]
            similarity = 1.0 - (dist / 2.0)
            meta = res['metadatas'][0][i]
            results.append({
                'id':             res['ids'][0][i],
                'distance':       dist,
                'similarity':     similarity,
                'metadata':       meta,
                'document':       res['documents'][0][i],
                'case_dir':       meta.get('case_dir', ''),
                'inlet_velocity': (meta.get('inlet_Ux', 0),
                                   meta.get('inlet_Uy', 0),
                                   meta.get('inlet_Uz', 0)),
                'k_inlet':        meta.get('k_inlet', 0.15),
                'epsilon_inlet':  meta.get('epsilon_inlet', 3e-5),
            })
        return results

    def query_by_inlet_direction(self,
                                  azimuth_deg: float,
                                  tol_deg: float = 30.0) -> List[str]:
        """
        Filter cases by approximate inlet azimuth angle.
        Used to pre-filter before vector search.
        """
        lo = azimuth_deg - tol_deg
        hi = azimuth_deg + tol_deg
        try:
            res = self._col.get(
                where={"$and": [
                    {"inlet_azimuth_deg": {"$gte": float(lo)}},
                    {"inlet_azimuth_deg": {"$lte": float(hi)}},
                ]},
                include=[],
            )
            return res['ids']
        except Exception:
            return self.list_cases()

    # ────────────────────────────────────────────────────────────────────────
    # Document builder
    # ────────────────────────────────────────────────────────────────────────

    @staticmethod
    def build_document(case_id: str,
                        features: Dict[str, float],
                        raw: Dict[str, Any]) -> str:
        """
        Build a human-readable summary string for LLM context injection.
        """
        Ux, Uy, Uz = raw['inlet_velocity']
        U_mag = features.get('inlet_magnitude', 0)
        azi   = features.get('inlet_azimuth_deg', 0)
        Re    = features.get('Re_building', 0)

        geom = raw.get('geom_features', {})
        stats = raw.get('field_stats', {})

        lines = [
            f"=== CFD Case: {case_id} ===",
            f"Solver: simpleFoam | Turbulence: k-epsilon (RANS)",
            "",
            "── Inlet Boundary Condition ─────────────────────────",
            f"  Velocity vector  : ({Ux:.3f}, {Uy:.3f}, {Uz:.3f}) m/s",
            f"  Magnitude        : {U_mag:.3f} m/s",
            f"  Wind azimuth     : {azi:.1f}°  (0°=East, 90°=North)",
            f"  k_inlet          : {features.get('k_inlet', 0):.4e} m²/s²",
            f"  ε_inlet          : {features.get('epsilon_inlet', 0):.4e} m²/s³",
            f"  Turbulence intens: {features.get('turbulence_intensity', 0)*100:.1f}%",
            f"  Reynolds number  : {Re:.2e}",
            "",
            "── Building Geometry ────────────────────────────────",
            f"  BBox (x,y,z)     : ({geom.get('geom_bbox_x',0):.1f},"
            f" {geom.get('geom_bbox_y',0):.1f},"
            f" {geom.get('geom_bbox_z',0):.1f}) m",
            f"  Max height       : {geom.get('geom_max_height',0):.1f} m",
            f"  Footprint area   : {geom.get('geom_footprint_area',0):.0f} m²",
            f"  Volume (est.)    : {geom.get('geom_volume',0):.0f} m³",
            f"  Aspect ratio XY  : {geom.get('geom_aspect_ratio_xy',1):.2f}",
            f"  Surface area     : {geom.get('geom_surface_area',0):.0f} m²",
            f"  Vertex count     : {int(geom.get('geom_vertex_count',0))}",
            "",
            "── Converged Field Statistics (4000 iterations) ─────",
            f"  p_mean / p_max / p_min : {stats.get('p_mean',0):.1f} / "
            f"{stats.get('p_max',0):.1f} / {stats.get('p_min',0):.1f} Pa",
            f"  U_mag mean/max/min     : {stats.get('U_mag_mean',0):.2f} / "
            f"{stats.get('U_mag_max',0):.2f} / {stats.get('U_mag_min',0):.2f} m/s",
        ]

        return "\n".join(lines)
