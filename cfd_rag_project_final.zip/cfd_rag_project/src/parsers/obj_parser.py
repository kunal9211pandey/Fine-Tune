"""
OBJ geometry parser for building CFD cases.

Extracts physics-meaningful geometric descriptors from .obj files:
  - Bounding box and dimensions
  - Centroid of building mass
  - Approximate volume and surface area
  - Maximum height, footprint area
  - Aspect ratios
  - Building count (separate 'o' objects)
  - Orientation / principal axis (via PCA)
  - Compactness ratio
"""
import re
import numpy as np
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional


def parse_obj(path: Path) -> Dict[str, Any]:
    """
    Parse an OBJ file and return structured geometry data.

    Returns
    -------
    dict with keys:
      vertices  : np.ndarray (N, 3)
      faces     : list of list[int]  (0-indexed)
      objects   : dict  name → {'vertices': idx_list, 'faces': idx_list}
      metadata  : dict  (comments parsed as key: value)
    """
    vertices: List[List[float]] = []
    faces:    List[List[int]]   = []
    objects:  Dict[str, dict]   = {}
    metadata: Dict[str, str]    = {}
    current_object = "__default__"

    with open(path, 'r', errors='replace') as f:
        for line in f:
            line = line.strip()

            # Metadata from comments  # Key: Value
            if line.startswith('#'):
                m = re.match(r'#\s+(.+?):\s+(.+)', line)
                if m:
                    metadata[m.group(1).strip()] = m.group(2).strip()
                continue

            parts = line.split()
            if not parts:
                continue

            token = parts[0]

            if token == 'o':
                current_object = ' '.join(parts[1:])
                if current_object not in objects:
                    objects[current_object] = {'vertex_indices': [], 'face_indices': []}

            elif token == 'v':
                idx = len(vertices)
                vertices.append([float(p) for p in parts[1:4]])
                if current_object in objects:
                    objects[current_object]['vertex_indices'].append(idx)

            elif token == 'f':
                # Support: f v1 v2 ... or f v1/vt1/vn1 ...
                raw = [p.split('/')[0] for p in parts[1:]]
                face = [int(r) - 1 for r in raw if r]   # OBJ is 1-indexed
                if len(face) >= 3:
                    face_idx = len(faces)
                    faces.append(face)
                    if current_object in objects:
                        objects[current_object]['face_indices'].append(face_idx)

    verts = np.array(vertices, dtype=np.float64) if vertices else np.zeros((0, 3))
    return {
        'vertices': verts,
        'faces':    faces,
        'objects':  objects,
        'metadata': metadata,
    }


def _triangle_area(p0: np.ndarray, p1: np.ndarray, p2: np.ndarray) -> float:
    return 0.5 * np.linalg.norm(np.cross(p1 - p0, p2 - p0))


def _triangulate_face(verts: np.ndarray, face: List[int]) -> List[Tuple]:
    """Fan triangulation of an n-gon face."""
    tris = []
    for i in range(1, len(face) - 1):
        tris.append((face[0], face[i], face[i+1]))
    return tris


def compute_surface_area(verts: np.ndarray, faces: List[List[int]]) -> float:
    """Compute total surface area using triangle fan decomposition."""
    total = 0.0
    for face in faces:
        for tri in _triangulate_face(verts, face):
            p0, p1, p2 = verts[tri[0]], verts[tri[1]], verts[tri[2]]
            total += _triangle_area(p0, p1, p2)
    return total


def compute_volume_estimate(verts: np.ndarray, faces: List[List[int]]) -> float:
    """
    Estimate enclosed volume using divergence theorem (signed tetrahedra).
    Assumes a closed or approximately closed mesh.
    """
    vol = 0.0
    for face in faces:
        for tri in _triangulate_face(verts, face):
            p0, p1, p2 = verts[tri[0]], verts[tri[1]], verts[tri[2]]
            vol += np.dot(p0, np.cross(p1, p2)) / 6.0
    return abs(vol)


def extract_geometry_features(obj_path: Path) -> Dict[str, float]:
    """
    Extract all physics-meaningful geometry features from an OBJ file.

    Returns a flat dict of named float features.
    """
    data = parse_obj(obj_path)
    verts = data['vertices']
    faces = data['faces']
    meta  = data['metadata']

    if len(verts) == 0:
        return _zero_features()

    # ── Bounding box ─────────────────────────────────────────────────────────
    bbox_min = verts.min(axis=0)   # (x_min, y_min, z_min)
    bbox_max = verts.max(axis=0)   # (x_max, y_max, z_max)
    bbox_span = bbox_max - bbox_min  # (Lx, Ly, Lz)

    centroid = verts.mean(axis=0)

    # ── Shape dimensions ─────────────────────────────────────────────────────
    max_height   = float(bbox_max[2])   # z-axis is up in OpenFOAM
    footprint_area = float(bbox_span[0] * bbox_span[1])
    aspect_ratio_xy = (float(bbox_span[0]) / float(bbox_span[1])
                       if bbox_span[1] > 0 else 1.0)

    # ── Surface area & volume ─────────────────────────────────────────────────
    surface_area = compute_surface_area(verts, faces)
    volume       = compute_volume_estimate(verts, faces)

    # ── Building count (number of 'o' objects in file, excluding non-buildings) ─
    building_count = max(1, len([k for k in data['objects']
                                  if 'building' in k.lower() or
                                     'tower'    in k.lower() or
                                     'zone'     in k.lower()]))

    # ── Orientation via PCA ───────────────────────────────────────────────────
    # Project onto XY plane only (horizontal orientation)
    xy = verts[:, :2] - verts[:, :2].mean(axis=0)
    try:
        cov = np.cov(xy.T)
        eigenvalues, eigenvectors = np.linalg.eigh(cov)
        # Principal axis angle in XY plane
        principal_angle_deg = float(np.degrees(
            np.arctan2(eigenvectors[1, -1], eigenvectors[0, -1])
        ))
    except Exception:
        principal_angle_deg = 0.0

    # ── Compactness (how much perimeter area vs volume) ───────────────────────
    compactness = (surface_area / volume) if volume > 0 else 0.0

    # ── Metadata from buildingsOrig.obj (if available) ────────────────────────
    try:
        num_floors    = float(meta.get('Number of Floors', 0))
        bldg_height_m = float(meta.get('Building Height', '0').replace('m','').strip())
        wwr           = float(meta.get('WWR', 0))
        gco           = float(meta.get('Ground Coverage', 0))
    except Exception:
        num_floors = bldg_height_m = wwr = gco = 0.0

    return {
        'geom_bbox_x':        float(bbox_span[0]),
        'geom_bbox_y':        float(bbox_span[1]),
        'geom_bbox_z':        float(bbox_span[2]),
        'geom_centroid_x':    float(centroid[0]),
        'geom_centroid_y':    float(centroid[1]),
        'geom_centroid_z':    float(centroid[2]),
        'geom_volume':        float(volume),
        'geom_surface_area':  float(surface_area),
        'geom_max_height':    float(max_height),
        'geom_footprint_area': float(footprint_area),
        'geom_aspect_ratio_xy': float(aspect_ratio_xy),
        'geom_vertex_count':  float(len(verts)),
        'geom_building_count': float(building_count),
        'geom_principal_angle_deg': float(principal_angle_deg),
        'geom_compactness':   float(compactness),
        # Metadata-derived (0 if not in OBJ)
        'meta_num_floors':    float(num_floors),
        'meta_bldg_height_m': float(bldg_height_m),
        'meta_wwr':           float(wwr),
        'meta_ground_coverage': float(gco),
    }


def _zero_features() -> Dict[str, float]:
    keys = [
        'geom_bbox_x', 'geom_bbox_y', 'geom_bbox_z',
        'geom_centroid_x', 'geom_centroid_y', 'geom_centroid_z',
        'geom_volume', 'geom_surface_area', 'geom_max_height',
        'geom_footprint_area', 'geom_aspect_ratio_xy', 'geom_vertex_count',
        'geom_building_count', 'geom_principal_angle_deg', 'geom_compactness',
        'meta_num_floors', 'meta_bldg_height_m', 'meta_wwr', 'meta_ground_coverage',
    ]
    return {k: 0.0 for k in keys}


def geometry_similarity(feat_a: Dict[str, float],
                         feat_b: Dict[str, float]) -> float:
    """
    Physics-informed similarity between two building geometries.
    Returns a score in [0, 1] where 1 = identical.

    Weighted by physical importance:
      - Building height (most important for flow field)
      - Footprint area
      - Aspect ratio (controls wake structure)
      - Volume (scales drag)
    """
    weights = {
        'geom_max_height':       0.30,
        'geom_footprint_area':   0.20,
        'geom_volume':           0.15,
        'geom_aspect_ratio_xy':  0.15,
        'geom_bbox_x':           0.05,
        'geom_bbox_y':           0.05,
        'geom_building_count':   0.05,
        'meta_bldg_height_m':    0.05,
    }

    total_w = 0.0
    sim = 0.0
    for key, w in weights.items():
        va = feat_a.get(key, 0.0)
        vb = feat_b.get(key, 0.0)
        denom = max(abs(va), abs(vb), 1e-9)
        ratio = 1.0 - min(abs(va - vb) / denom, 1.0)
        sim += w * ratio
        total_w += w

    return sim / total_w if total_w > 0 else 0.0
