"""
OpenFOAM file parser – handles both boundary-condition files (0/U, 0/p, 0/k, 0/epsilon)
and large converged field files (4000/p, 4000/U).

OpenFOAM ASCII field format:
  internalField   nonuniform List<scalar>
  N
  (
  val1
  val2
  ...
  )
  ;

or for vectors:
  internalField   nonuniform List<vector>
  N
  (
  (ux uy uz)
  ...
  )
  ;
"""
import re
import numpy as np
from pathlib import Path
from typing import Dict, Any, Optional, Tuple


# ────────────────────────────────────────────────────────────────────────────
# Low-level helpers
# ────────────────────────────────────────────────────────────────────────────

def _strip_comments(text: str) -> str:
    """Remove C-style /* ... */ and // comments."""
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    text = re.sub(r'//[^\n]*', '', text)
    return text


def _read_text(path: Path) -> str:
    with open(path, 'r', errors='replace') as f:
        return f.read()


# ────────────────────────────────────────────────────────────────────────────
# Header / metadata parsing
# ────────────────────────────────────────────────────────────────────────────

def parse_foam_header(path: Path) -> Dict[str, str]:
    """Parse FoamFile metadata block."""
    text = _read_text(path)
    block = re.search(r'FoamFile\s*\{(.*?)\}', text, re.DOTALL)
    if not block:
        return {}
    result = {}
    for line in block.group(1).splitlines():
        m = re.match(r'\s*(\w+)\s+(.+?);', line)
        if m:
            result[m.group(1)] = m.group(2).strip()
    return result


# ────────────────────────────────────────────────────────────────────────────
# Boundary-condition (0/ files) parsing
# ────────────────────────────────────────────────────────────────────────────

def parse_vector_value(s: str) -> Tuple[float, float, float]:
    """Parse '(x y z)' or 'uniform (x y z)' into a 3-tuple."""
    m = re.search(r'\(\s*([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)'
                  r'\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)'
                  r'\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s*\)', s)
    if m:
        return float(m.group(1)), float(m.group(2)), float(m.group(3))
    raise ValueError(f"Cannot parse vector from: {s!r}")


def parse_scalar_value(s: str) -> float:
    """Parse 'uniform 0' or '101325' into a float."""
    m = re.search(r'([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)', s)
    if m:
        return float(m.group(1))
    raise ValueError(f"Cannot parse scalar from: {s!r}")


def parse_U_bc(path: Path) -> Dict[str, Any]:
    """
    Parse 0/U file.
    Returns dict with:
      inlet_velocity (3-tuple): (Ux, Uy, Uz) in m/s
      boundary_conditions (dict): patch → type + value
      Uinlet_raw (str): raw $Uinlet expression
    """
    text = _read_text(path)
    text_nc = _strip_comments(text)

    # Extract Uinlet macro variable
    m = re.search(r'Uinlet\s+\(([^)]+)\)', text_nc)
    if m:
        vals = list(map(float, m.group(1).split()))
        inlet_vel = tuple(vals[:3])
    else:
        inlet_vel = (0.0, 0.0, 0.0)

    # Parse boundaryField block
    bc = {}
    bf_match = re.search(r'boundaryField\s*\{(.*)\}', text_nc, re.DOTALL)
    if bf_match:
        bf_text = bf_match.group(1)
        # Find each patch block
        patches = re.finditer(
            r'(\w+)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}', bf_text)
        for p in patches:
            pname = p.group(1)
            if pname.startswith('#'):
                continue
            ptext = p.group(2)
            ptype = re.search(r'type\s+(\S+?);', ptext)
            pval  = re.search(r'value\s+(.+?);', ptext)
            bc[pname] = {
                'type':  ptype.group(1) if ptype else 'unknown',
                'value': pval.group(1).strip() if pval else None
            }

    return {
        'inlet_velocity': inlet_vel,
        'boundary_conditions': bc,
    }


def parse_p_bc(path: Path) -> Dict[str, Any]:
    """Parse 0/p file."""
    text  = _read_text(path)
    text_nc = _strip_comments(text)

    # internalField value
    m = re.search(r'internalField\s+uniform\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)', text_nc)
    p_internal = float(m.group(1)) if m else 0.0

    bc = {}
    bf_match = re.search(r'boundaryField\s*\{(.*)\}', text_nc, re.DOTALL)
    if bf_match:
        bf_text = bf_match.group(1)
        patches = re.finditer(
            r'(\w+)\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}', bf_text)
        for p in patches:
            pname = p.group(1)
            if pname.startswith('#'):
                continue
            ptext = p.group(2)
            ptype = re.search(r'type\s+(\S+?);', ptext)
            pval  = re.search(r'p0\s+uniform\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)', ptext)
            bc[pname] = {
                'type':  ptype.group(1) if ptype else 'unknown',
                'p0':    float(pval.group(1)) if pval else None,
            }

    return {'p_internal': p_internal, 'boundary_conditions': bc}


def parse_k_bc(path: Path) -> Dict[str, Any]:
    """Parse 0/k file and return k_inlet value."""
    text = _read_text(path)
    text_nc = _strip_comments(text)
    m = re.search(r'kInlet\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)', text_nc)
    k_inlet = float(m.group(1)) if m else 0.15
    return {'k_inlet': k_inlet}


def parse_epsilon_bc(path: Path) -> Dict[str, Any]:
    """Parse 0/epsilon file and return epsilon_inlet value."""
    text = _read_text(path)
    text_nc = _strip_comments(text)
    m = re.search(r'epsilonInlet\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)', text_nc)
    eps_inlet = float(m.group(1)) if m else 3e-5
    return {'epsilon_inlet': eps_inlet}


# ────────────────────────────────────────────────────────────────────────────
# Large field files (4000/p, 4000/U) – statistics only for indexing
# ────────────────────────────────────────────────────────────────────────────

def _read_internal_scalar_fast(path: Path,
                                max_cells: Optional[int] = None) -> np.ndarray:
    """
    Efficiently read 'internalField nonuniform List<scalar>' from an
    OpenFOAM field file.  Reads only up to *max_cells* values (for stats).
    """
    with open(path, 'r', errors='replace') as f:
        text = f.read()

    # Locate the opening parenthesis of internalField
    m = re.search(r'internalField\s+nonuniform\s+List<scalar>\s+(\d+)\s*\(', text)
    if not m:
        # Try uniform value
        m2 = re.search(r'internalField\s+uniform\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)', text)
        if m2:
            return np.array([float(m2.group(1))])
        raise ValueError(f"Cannot find internalField in {path}")

    n_cells = int(m.group(1))
    start   = m.end()          # right after '('

    # Extract numeric block
    end_marker = text.find(')', start)
    block      = text[start:end_marker]

    # Parse all floats
    vals = np.fromstring(block, dtype=np.float64, sep='\n')
    if max_cells and len(vals) > max_cells:
        vals = vals[:max_cells]
    return vals


def _read_internal_vector_fast(path: Path,
                                max_cells: Optional[int] = None) -> np.ndarray:
    """
    Efficiently read 'internalField nonuniform List<vector>' from an
    OpenFOAM field file.  Returns array of shape (N, 3).
    """
    with open(path, 'r', errors='replace') as f:
        text = f.read()

    m = re.search(r'internalField\s+nonuniform\s+List<vector>\s+(\d+)\s*\(', text)
    if not m:
        m2 = re.search(r'internalField\s+uniform\s+\(\s*'
                        r'([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+'
                        r'([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+'
                        r'([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s*\)', text)
        if m2:
            return np.array([[float(m2.group(i)) for i in (1,2,3)]])
        raise ValueError(f"Cannot find internalField in {path}")

    n_cells = int(m.group(1))
    start   = m.end()
    end_marker = text.rfind(')', start)
    block      = text[start:end_marker]

    # Parse triplets  (x y z)
    pattern = re.compile(
        r'\(\s*([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)'
        r'\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)'
        r'\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s*\)')
    matches = pattern.findall(block)
    if max_cells:
        matches = matches[:max_cells]
    return np.array([[float(x), float(y), float(z)] for x, y, z in matches])


def compute_field_statistics(path_p: Path, path_U: Path,
                              sample_size: int = 10000) -> Dict[str, float]:
    """
    Compute statistical features from converged p and U fields.
    Uses a random sample of *sample_size* cells for speed.
    """
    p_vals  = _read_internal_scalar_fast(path_p, max_cells=sample_size)
    U_vecs  = _read_internal_vector_fast(path_U, max_cells=sample_size)
    U_mag   = np.linalg.norm(U_vecs, axis=1)

    return {
        'p_mean':     float(np.mean(p_vals)),
        'p_max':      float(np.max(p_vals)),
        'p_min':      float(np.min(p_vals)),
        'p_std':      float(np.std(p_vals)),
        'U_mag_mean': float(np.mean(U_mag)),
        'U_mag_max':  float(np.max(U_mag)),
        'U_mag_min':  float(np.min(U_mag)),
        'U_mag_std':  float(np.std(U_mag)),
    }


# ────────────────────────────────────────────────────────────────────────────
# Full field reader (for physics engine – used only on matched case)
# ────────────────────────────────────────────────────────────────────────────

def read_full_p_field(path: Path) -> Tuple[np.ndarray, str, str]:
    """
    Read complete pressure field.
    Returns: (values_array, header_text, footer_text)
    """
    with open(path, 'r', errors='replace') as f:
        text = f.read()

    m = re.search(r'(internalField\s+nonuniform\s+List<scalar>\s+\d+\s*\()', text)
    if not m:
        raise ValueError(f"Cannot parse internalField in {path}")

    header = text[:m.start()] + m.group(1)
    start  = m.end()
    end    = text.rfind(')', start)
    block  = text[start:end]
    footer = text[end:]

    vals = np.fromstring(block, dtype=np.float64, sep='\n')
    return vals, header, footer


def read_full_U_field(path: Path) -> Tuple[np.ndarray, str, str]:
    """
    Read complete velocity field.
    Returns: (array of shape (N,3), header_text, footer_text)
    """
    with open(path, 'r', errors='replace') as f:
        text = f.read()

    m = re.search(r'(internalField\s+nonuniform\s+List<vector>\s+\d+\s*\()', text)
    if not m:
        raise ValueError(f"Cannot parse internalField in {path}")

    header = text[:m.start()] + m.group(1)
    start  = m.end()
    end    = text.rfind(')', start)
    block  = text[start:end]
    footer = text[end:]

    pattern = re.compile(
        r'\(\s*([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)'
        r'\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)'
        r'\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s*\)')
    matches = pattern.findall(block)
    vecs = np.array([[float(x), float(y), float(z)] for x, y, z in matches])
    return vecs, header, footer


# ────────────────────────────────────────────────────────────────────────────
# Mesh parameter reader
# ────────────────────────────────────────────────────────────────────────────

def parse_mesh_parameters(path: Path) -> Dict[str, float]:
    """Parse system/meshParameters for domain bounds."""
    text = _read_text(path)
    params = {}
    for key in ['xMin', 'xMax', 'yMin', 'yMax', 'zMin', 'zMax']:
        m = re.search(rf'{key}\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)', text)
        if m:
            params[key] = float(m.group(1))
    return params


# ────────────────────────────────────────────────────────────────────────────
# OpenFOAM writer helpers
# ────────────────────────────────────────────────────────────────────────────

def write_foam_scalar_field(path: Path, values: np.ndarray,
                             header: str, footer: str) -> None:
    """Write a scalar field back in OpenFOAM format, preserving header/footer."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w') as f:
        f.write(header)
        f.write('\n')
        for v in values:
            f.write(f'{v:.6g}\n')
        f.write(footer)


def write_foam_vector_field(path: Path, vectors: np.ndarray,
                             header: str, footer: str) -> None:
    """Write a vector field back in OpenFOAM format, preserving header/footer."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w') as f:
        f.write(header)
        f.write('\n')
        for v in vectors:
            f.write(f'({v[0]:.6g} {v[1]:.6g} {v[2]:.6g})\n')
        f.write(footer)


def write_foam_bc_U(path: Path, inlet_velocity: tuple,
                     k_inlet: float, epsilon_inlet: float,
                     turbulence_model: str = "kEpsilon") -> None:
    """Write a complete 0/U boundary-condition file."""
    Ux, Uy, Uz = inlet_velocity
    path.parent.mkdir(parents=True, exist_ok=True)
    content = f"""/*--------------------------------*- C++ -*----------------------------------*\\
  =========                 |
  \\\\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\\\    /   O peration     | CFD-RAG Physics Engine
\\*---------------------------------------------------------------------------*/
FoamFile
{{
    version     2.0;
    format      ascii;
    class       volVectorField;
    object      U;
}}
// ************************************************************************* //

Uinlet          ({Ux} {Uy} {Uz});

dimensions      [0 1 -1 0 0 0 0];

internalField   uniform (0 0 0);

boundaryField
{{
    inlet
    {{
        type            fixedValue;
        value           uniform $Uinlet;
    }}

    outlet
    {{
        type            pressureInletOutletVelocity;
        value           uniform (0 0 0);
    }}

    wall
    {{
        type            slip;
    }}
    ground
    {{
        type            noSlip;
    }}

    buildings
    {{
        type            noSlip;
    }}

    #includeEtc "caseDicts/setConstraintTypes"
}}

// ************************************************************************* //
"""
    path.write_text(content)


def write_foam_bc_p(path: Path, p_ref: float = 0.0) -> None:
    """Write a complete 0/p boundary-condition file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    content = f"""/*--------------------------------*- C++ -*----------------------------------*\\
  =========                 |
  \\\\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\\\    /   O peration     | CFD-RAG Physics Engine
\\*---------------------------------------------------------------------------*/
FoamFile
{{
    version     2.0;
    format      ascii;
    class       volScalarField;
    object      p;
}}
// ************************************************************************* //

dimensions      [0 2 -2 0 0 0 0];

internalField   uniform {p_ref};

boundaryField
{{
    inlet
    {{
        type            zeroGradient;
    }}

    outlet
    {{
        type            totalPressure;
        p0              uniform 101325;
        gamma           1.4;
        value           uniform {p_ref};
    }}

    wall
    {{
        type            zeroGradient;
    }}

    buildings
    {{
        type            zeroGradient;
    }}

    #includeEtc "caseDicts/setConstraintTypes"
}}

// ************************************************************************* //
"""
    path.write_text(content)
