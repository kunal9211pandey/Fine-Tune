"""
Feature extractor for CFD cases.

Combines OpenFOAM boundary conditions + OBJ geometry + converged field
statistics into a fixed-length physics feature vector suitable for
ChromaDB vector similarity search.

Feature vector layout (33 dimensions):
  [0:6]   Inlet velocity features
  [6:9]   Turbulence inlet conditions
  [9]     Reynolds number
  [10:16] Geometry bounding box + centroid
  [16:22] Geometry shape descriptors
  [22:25] Domain dimensions
  [25:33] Converged field statistics
"""
import numpy as np
from pathlib import Path
from typing import Dict, Any, Optional, List

from src.parsers.foam_parser import (
    parse_U_bc, parse_k_bc, parse_epsilon_bc,
    parse_mesh_parameters, compute_field_statistics,
)
from src.parsers.obj_parser import extract_geometry_features
import config


# ────────────────────────────────────────────────────────────────────────────
# Inlet velocity decomposition
# ────────────────────────────────────────────────────────────────────────────

def inlet_features(Ux: float, Uy: float, Uz: float) -> Dict[str, float]:
    """
    Decompose inlet velocity (Ux, Uy, Uz) into physics features.

    azimuth  : angle in XY plane (wind compass direction), degrees
    elevation: angle above XY plane (ground), degrees
    """
    mag = float(np.sqrt(Ux**2 + Uy**2 + Uz**2))
    azimuth_rad   = float(np.arctan2(Uy, Ux))       # horizontal angle
    elevation_rad = float(np.arctan2(Uz, np.sqrt(Ux**2 + Uy**2)))
    return {
        'inlet_Ux':           Ux,
        'inlet_Uy':           Uy,
        'inlet_Uz':           Uz,
        'inlet_magnitude':    mag,
        'inlet_azimuth_deg':  float(np.degrees(azimuth_rad)),
        'inlet_elevation_deg': float(np.degrees(elevation_rad)),
    }


def turbulence_features(k_inlet: float, epsilon_inlet: float,
                         U_mag: float) -> Dict[str, float]:
    """
    Turbulence inlet feature decomposition.

    Turbulence intensity I = sqrt(2k/3) / U_ref
    Turbulent length scale L = Cμ^(3/4) * k^(3/2) / ε
    """
    I  = float(np.sqrt(2.0 * k_inlet / 3.0) / max(U_mag, 1e-9))
    return {
        'k_inlet':             k_inlet,
        'epsilon_inlet':       epsilon_inlet,
        'turbulence_intensity': I,
    }


def reynolds_number(U_mag: float, L_ref: float,
                     nu: float = config.NU) -> float:
    """
    Building Reynolds number: Re = U_inlet * H_building / ν

    H_building ~ characteristic length (use domain height as proxy if needed)
    """
    return U_mag * L_ref / nu


# ────────────────────────────────────────────────────────────────────────────
# Main case feature extractor
# ────────────────────────────────────────────────────────────────────────────

def extract_case_features(case_dir: Path,
                           has_converged_fields: bool = True) -> Dict[str, Any]:
    """
    Extract all features for one CFD case.

    Parameters
    ----------
    case_dir : Path
        Root of the OpenFOAM case (contains 0/, constant/, system/)
    has_converged_fields : bool
        If True, also read 4000/p and 4000/U for field statistics.
        Set False for a new query case that has no converged solution yet.

    Returns
    -------
    dict with:
      'features'     : Dict[str, float]  – all named features
      'feature_vec'  : np.ndarray (N,)   – normalised feature vector for ChromaDB
      'raw'          : dict               – raw parsed values for physics engine
    """
    case_dir = Path(case_dir)
    features: Dict[str, float] = {}
    raw: Dict[str, Any] = {'case_dir': str(case_dir)}

    # ── 1. Inlet velocity ──────────────────────────────────────────────────
    u_bc = parse_U_bc(case_dir / '0' / 'U')
    Ux, Uy, Uz = u_bc['inlet_velocity']
    raw['inlet_velocity'] = (Ux, Uy, Uz)
    features.update(inlet_features(Ux, Uy, Uz))

    # ── 2. Turbulence conditions ───────────────────────────────────────────
    k_bc  = parse_k_bc(case_dir / '0' / 'k')
    e_bc  = parse_epsilon_bc(case_dir / '0' / 'epsilon')
    k_in  = k_bc['k_inlet']
    ep_in = e_bc['epsilon_inlet']
    raw.update({'k_inlet': k_in, 'epsilon_inlet': ep_in})
    features.update(turbulence_features(k_in, ep_in, features['inlet_magnitude']))

    # ── 3. Geometry ────────────────────────────────────────────────────────
    obj_path = case_dir / 'constant' / 'triSurface' / 'buildings.obj'
    if not obj_path.exists():
        # Try buildingsOrig.obj
        obj_path = case_dir / 'constant' / 'triSurface' / 'buildingsOrig.obj'

    geom_feats = extract_geometry_features(obj_path)
    raw['geom_features'] = geom_feats
    raw['obj_path'] = str(obj_path)
    features.update({k: v for k, v in geom_feats.items()
                     if k in config.FEATURE_NAMES})

    # Reference length for Re: use max building height or geom_bbox_z
    L_ref = geom_feats.get('geom_max_height', 60.0)
    if L_ref < 1.0:
        L_ref = geom_feats.get('geom_bbox_z', 60.0)
    raw['L_ref'] = L_ref

    # ── 4. Reynolds number ─────────────────────────────────────────────────
    Re = reynolds_number(features['inlet_magnitude'], L_ref)
    features['Re_building'] = Re

    # ── 5. Domain dimensions ───────────────────────────────────────────────
    mp_path = case_dir / 'system' / 'meshParameters'
    if not mp_path.exists():
        # Look one level up (some cases share system/)
        mp_path = case_dir.parent / 'system' / 'meshParameters'
    if mp_path.exists():
        mesh = parse_mesh_parameters(mp_path)
        features['domain_x_span'] = mesh.get('xMax', 0) - mesh.get('xMin', 0)
        features['domain_y_span'] = mesh.get('yMax', 0) - mesh.get('yMin', 0)
        features['domain_z_span'] = mesh.get('zMax', 0) - mesh.get('zMin', 0)
    else:
        features['domain_x_span'] = 181.5
        features['domain_y_span'] = 166.5
        features['domain_z_span'] = 90.0

    # ── 6. Converged field statistics ──────────────────────────────────────
    if has_converged_fields:
        p_path = case_dir / str(config.CONVERGENCE_TIME) / 'p'
        u_path = case_dir / str(config.CONVERGENCE_TIME) / 'U'
        if p_path.exists() and u_path.exists():
            stats = compute_field_statistics(p_path, u_path, sample_size=8000)
            raw['field_stats'] = stats
            features.update(stats)
        else:
            features.update(_zero_field_stats())
    else:
        features.update(_zero_field_stats())

    # ── 7. Build feature vector ────────────────────────────────────────────
    vec = features_to_vector(features)

    return {
        'features':    features,
        'feature_vec': vec,
        'raw':         raw,
    }


def _zero_field_stats() -> Dict[str, float]:
    return {
        'p_mean': 0.0, 'p_max': 0.0, 'p_min': 0.0, 'p_std': 0.0,
        'U_mag_mean': 0.0, 'U_mag_max': 0.0, 'U_mag_min': 0.0, 'U_mag_std': 0.0,
    }


def features_to_vector(features: Dict[str, float]) -> np.ndarray:
    """Convert feature dict to numpy array in canonical order."""
    vec = np.array([features.get(k, 0.0) for k in config.FEATURE_NAMES],
                   dtype=np.float64)
    return vec


def normalise_vector(vec: np.ndarray,
                     mu: Optional[np.ndarray] = None,
                     sigma: Optional[np.ndarray] = None) -> np.ndarray:
    """Z-score normalise a feature vector."""
    if mu is None or sigma is None:
        return vec
    return (vec - mu) / np.where(sigma > 1e-9, sigma, 1.0)


# ────────────────────────────────────────────────────────────────────────────
# New query feature extraction (no converged fields)
# ────────────────────────────────────────────────────────────────────────────

def extract_query_features(obj_path: Path,
                            inlet_velocity: tuple,
                            system_dir: Optional[Path] = None) -> Dict[str, Any]:
    """
    Extract features for a new user query (inlet + obj).
    No converged fields available, so field stats are zeroed.

    Parameters
    ----------
    obj_path       : Path to the new buildings.obj file
    inlet_velocity : (Ux, Uy, Uz) tuple
    system_dir     : optional path to system/ for mesh parameters

    Returns
    -------
    Same structure as extract_case_features()
    """
    Ux, Uy, Uz = inlet_velocity
    features: Dict[str, float] = {}
    raw: Dict[str, Any] = {
        'case_dir':       None,
        'inlet_velocity': (Ux, Uy, Uz),
        'obj_path':       str(obj_path),
    }

    features.update(inlet_features(Ux, Uy, Uz))

    # Turbulence from inlet velocity using standard ABL correlations
    U_mag = features['inlet_magnitude']
    I     = config.TURBULENCE_INTENSITY  # e.g. 0.10
    k_in  = 1.5 * (I * U_mag) ** 2
    L_ref_guess = 60.0  # will update after geom
    ep_in = (config.CMU ** 0.75) * (k_in ** 1.5) / max(L_ref_guess, 1.0)
    raw.update({'k_inlet': k_in, 'epsilon_inlet': ep_in})
    features.update(turbulence_features(k_in, ep_in, U_mag))

    # Geometry
    geom_feats = extract_geometry_features(Path(obj_path))
    raw['geom_features'] = geom_feats
    features.update({k: v for k, v in geom_feats.items()
                     if k in config.FEATURE_NAMES})

    L_ref = geom_feats.get('geom_max_height', 60.0)
    if L_ref < 1.0:
        L_ref = geom_feats.get('geom_bbox_z', 60.0)
    raw['L_ref'] = L_ref

    # Recalculate epsilon with true L_ref
    ep_in = (config.CMU ** 0.75) * (k_in ** 1.5) / max(L_ref, 1.0)
    features['epsilon_inlet'] = ep_in

    features['Re_building'] = reynolds_number(U_mag, L_ref)

    # Domain
    if system_dir and (system_dir / 'meshParameters').exists():
        mesh = parse_mesh_parameters(system_dir / 'meshParameters')
        features['domain_x_span'] = mesh.get('xMax', 0) - mesh.get('xMin', 0)
        features['domain_y_span'] = mesh.get('yMax', 0) - mesh.get('yMin', 0)
        features['domain_z_span'] = mesh.get('zMax', 0) - mesh.get('zMin', 0)
    else:
        features['domain_x_span'] = 181.5
        features['domain_y_span'] = 166.5
        features['domain_z_span'] = 90.0

    # Zero field stats (not yet computed)
    features.update(_zero_field_stats())

    return {
        'features':    features,
        'feature_vec': features_to_vector(features),
        'raw':         raw,
    }
