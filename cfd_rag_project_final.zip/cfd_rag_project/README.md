# CFD Physics-Based RAG — Building Wind Field Predictor

Predicts OpenFOAM **pressure (p)** and **velocity (U)** fields around buildings
using a **Physics-Based RAG architecture** backed by a Groq LLM.

No chatbot. No Q&A. Pure prediction pipeline:
> `inlet_velocity + buildings.obj` → `4000/p` + `4000/U` + full physics report

---

## Architecture

```
User Input: (Ux, Uy, Uz) + buildings.obj
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 1  Feature Extraction (33-dim physics vector)             │
│          • Inlet: Ux,Uy,Uz, |U|, azimuth, elevation            │
│          • Turbulence: k_in=1.5(IU)², ε_in=Cμ^0.75 k^1.5/L    │
│          • Re = U·H/ν                                           │
│          • Geometry: bbox, volume, height, aspect ratio (OBJ)  │
│          • Domain: xSpan, ySpan, zSpan (meshParameters)        │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 2  ChromaDB Vector Search  (cosine similarity, top-k)     │
│          39 OpenFOAM cases indexed as 33-dim feature vectors    │
│          Z-score normalised before storage                      │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 3  Groq LLM — Physics-Based Case Ranking                  │
│          Model: llama-3.3-70b-versatile                         │
│          • Compares query azimuth vs candidate azimuths         │
│          • Prioritises direction match over magnitude           │
│          • Assigns blending weights (JSON output)               │
│          • Flags azimuth correction need                        │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 4-5  Read matched fields + Navier-Stokes Scaling          │
│                                                                 │
│  Governing equations (incompressible steady RANS):              │
│    ∇·u = 0                          (continuity)                │
│    (u·∇)u = -∇(p/ρ) + ∇·[(ν+νt)∇u] (momentum)                │
│    (u·∇)k = Pk - ε + diffusion      (k-transport)              │
│    (u·∇)ε = C1ε(ε/k)Pk - C2ε(ε²/k) (ε-transport)             │
│                                                                 │
│  Scaling laws (same geometry, U_ref → U_new):                   │
│    u_new = R · u_ref × (|U_new|/|U_ref|)   [linear + rotation] │
│    p_new = p_ref × (|U_new|/|U_ref|)²      [quadratic]         │
│    k_new = k_ref × (|U_new|/|U_ref|)²      [quadratic]         │
│    ε_new = ε_ref × (|U_new|/|U_ref|)³      [cubic]             │
│                                                                 │
│  Direction rotation via Rodrigues' formula                      │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 6  Weighted Field Blending (multi-case interpolation)     │
│          w_i = exp(α·s_i) / Σexp(...)   α=8 if s>0.85          │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 7  Physics Flow Analysis                                  │
│          • High-p zones   → windward stagnation (Cp_max)        │
│          • Low-p zones    → leeward/roof suction (Cp_min)       │
│          • Wake region    → fraction of cells < 0.5×U_inlet     │
│          • Recirculation  → fraction of cells < 0.1×U_inlet     │
│          • Venturi effect → acceleration between buildings       │
│          • Structural risk → ΔP = ρ·q·(Cp_max - Cp_min)        │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 8  Groq LLM — Validation + Orientation                    │
│          • Validates Cp bounds, U_max ratio, bulk flow ratio    │
│          • Computes optimal rotation angle for min ΔP           │
│          • Estimates ΔCp reduction for rotation options         │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 9-10  OpenFOAM Output + Reports                           │
│             output/<case>/4000/p             ← pressure field   │
│             output/<case>/4000/U             ← velocity field   │
│             output/<case>/4000/k, epsilon    ← turbulence       │
│             output/<case>/0/U,p,k,eps,nut   ← boundary conds   │
│             output/<case>/system/            ← solver dicts     │
│             output/<case>/constant/          ← properties       │
│             output/<case>/prediction_report.json                │
│             output/<case>/prediction_report.txt                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env:
#   GROQ_API_KEY=your_key_here
#   DATASET_ROOT=/path/to/your/39/cases
```

### 3. Dataset structure
Each of your 39 cases should follow this OpenFOAM structure:
```
your_dataset/
  dublin_Spring/
    building2/
      0/U  0/p  0/k  0/epsilon  0/nut
      4000/p  4000/U  4000/k  4000/epsilon
      constant/triSurface/buildings.obj
      constant/momentumTransport
      constant/transportProperties
    building3/
    building4/
    building5/
  dublin_Summer/
    ...
  mohali_autumn/
    ...
  (total: 39 cases)
```

### 4. Index all 39 cases (run once)
```bash
python index_cases.py
```
Output:
```
Found 39 case(s)
Phase 1 — Feature extraction ...  39/39
Phase 2 — Fitting normaliser
Phase 3 — Indexing into ChromaDB
Vector DB total: 39 cases
```

### 5. Predict for a new building

**Option A — Velocity vector:**
```bash
python predict.py \
  --obj /path/to/new_building.obj \
  --inlet 0 2.6 0 \
  --name my_new_building
```

**Option B — Speed + compass direction:**
```bash
python predict.py \
  --obj /path/to/new_building.obj \
  --speed 5.0 \
  --direction S \
  --name my_new_building
```

**Option C — Without LLM (faster):**
```bash
python predict.py \
  --obj /path/to/new_building.obj \
  --inlet 1.5 2.5 0 \
  --no-llm
```

---

## Output Files

After running predict.py:
```
output/my_new_building/
  4000/
    p           ← kinematic pressure field  [m²/s²]  (204,531 cells)
    U           ← velocity vector field     [m/s]    (204,531 cells × 3)
    k           ← turbulent kinetic energy  [m²/s²]
    epsilon     ← dissipation rate          [m²/s³]
  0/
    U           ← inlet BC: fixedValue (Ux,Uy,Uz)
    p           ← outlet BC: totalPressure 101325 Pa
    k           ← inlet BC: k=1.5(I·U)²
    epsilon     ← inlet BC: ε=Cμ^0.75 k^1.5/L
    nut         ← wall: nutkWallFunction
  system/
    controlDict, fvSolution, fvSchemes, blockMeshDict, ...
  constant/
    momentumTransport (k-epsilon RAS)
    transportProperties (ν=1.5e-5 m²/s)
  prediction_report.json   ← full numeric report
  prediction_report.txt    ← human-readable report
```

---

## Physics Report Contents

The `prediction_report.txt` covers:

1. **Vector DB matches** — top-k cases with cosine similarity scores
2. **LLM selection** — which case was used and why (physics reasoning)
3. **Key physics scalars:**
   - `Re_building` — Reynolds number (UH/ν)
   - `Cp_windward_max` — peak stagnation pressure coefficient
   - `Cp_leeward_min` — peak suction coefficient
   - `ΔP (Pa)` — pressure differential across building
   - `Risk level` — LOW / MEDIUM / HIGH structural wind risk
   - `Wake fraction %` — % of domain cells in wake zone
   - `Max speed ratio` — Venturi acceleration (max U / U_inlet)
4. **Field statistics** — p and U mean/max/min/std
5. **Full flow analysis:**
   - Windward stagnation (Cp≈+1 theory vs actual)
   - Leeward suction & separation zones
   - Wake region extent (estimated L_wake / H)
   - Recirculation zones (backflow cells %)
   - Venturi corridors (acceleration between buildings)
   - Inlet approach flow uniformity
6. **Physics validation** — Bernoulli check, Cp bounds, continuity
7. **Optimal orientation recommendation** — rotation angle for min ΔP

---

## Physics Background

### Governing equations (OpenFOAM simpleFoam)
```
Continuity:  ∇·u = 0
Momentum:    (u·∇)u = -∇(p/ρ) + ∇·[(ν+νt)(∇u + ∇uᵀ)]

k-ε:  νt = Cμ k²/ε   (Cμ=0.09)
      k  = 1.5 (I·U)²         at inlet
      ε  = Cμ^0.75 k^1.5 / L  at inlet
      L  = building height H
```

### NS Scaling laws applied
```
Same geometry, U_ref → U_new:
  u_new = R · u_ref × (|U_new|/|U_ref|)
  p_new = p_ref × (|U_new|/|U_ref|)²
  k_new = k_ref × (|U_new|/|U_ref|)²
  ε_new = ε_ref × (|U_new|/|U_ref|)³
```

### Pressure coefficient
```
Cp = (p - p_∞) / (½ ρ U²)
Stagnation:  Cp ≈ +1.0
Separation:  Cp ≈ -0.5 to -1.5
Roof:        Cp ≈ -0.5 to -2.0
```

---

## Configuration (.env)

| Variable | Default | Description |
|---|---|---|
| `GROQ_API_KEY` | — | Groq API key (required) |
| `GROQ_MODEL` | `llama-3.3-70b-versatile` | LLM model |
| `DATASET_ROOT` | `./data/cases` | Path to 39 CFD cases |
| `CHROMA_DB_PATH` | `./data/vector_db` | ChromaDB storage |
| `OUTPUT_DIR` | `./output` | Prediction output |
| `TOP_K_MATCHES` | `5` | Top-k retrieval |
| `NU` | `1.5e-05` | Air kinematic viscosity m²/s |
| `RHO` | `1.225` | Air density kg/m³ |
| `TURBULENCE_INTENSITY` | `0.1` | Inlet I = 10% |

---

## Project Structure

```
cfd_rag_project/
├── config.py                    ← physics constants + paths
├── index_cases.py               ← index 39 cases into vector DB
├── predict.py                   ← run prediction for new case
├── requirements.txt
├── .env.example
├── src/
│   ├── pipeline.py              ← end-to-end pipeline (10 steps)
│   ├── parsers/
│   │   └── foam_parser.py       ← OpenFOAM ASCII reader/writer
│   │   └── obj_parser.py        ← OBJ geometry feature extractor
│   ├── features/
│   │   └── extractor.py         ← 33-dim physics feature vector
│   ├── vector_db/
│   │   └── store.py             ← ChromaDB wrapper (cosine)
│   ├── physics/
│   │   ├── scaling.py           ← NS-based field scaling + blending
│   │   └── analyzer.py          ← flow zone detection + analysis
│   └── llm/
│       └── agent.py             ← Groq: rank, validate, orientate
└── data/
    ├── cases/                   ← put your 39 CFD cases here
    └── vector_db/               ← auto-created by index_cases.py
```
