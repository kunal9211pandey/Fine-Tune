#!/usr/bin/env python3
"""
verify_setup.py
===============
Verify that all modules are importable and the sample case
can be fully parsed + feature-extracted.

Run this before index_cases.py to make sure everything is working.
Does NOT need GROQ_API_KEY. Does NOT need internet.

Usage:
  python verify_setup.py
"""
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

PASS = "[  OK  ]"
FAIL = "[ FAIL ]"


def check(label: str, fn):
    try:
        result = fn()
        print(f"{PASS}  {label}")
        return result
    except Exception as e:
        print(f"{FAIL}  {label}")
        traceback.print_exc()
        return None


def main():
    print("=" * 60)
    print("  CFD RAG Setup Verification")
    print("=" * 60)

    # ── 1. Config ──────────────────────────────────────────────────
    print("\n[1] Config & paths")
    cfg = check("config.py loads", lambda: __import__("config"))
    if cfg:
        check("DATASET_ROOT exists",
              lambda: cfg.DATASET_ROOT.exists() or True)  # warn only
        print(f"       DATASET_ROOT  = {cfg.DATASET_ROOT}")
        print(f"       CHROMA_DB     = {cfg.CHROMA_DB_PATH}")
        print(f"       OUTPUT_DIR    = {cfg.OUTPUT_DIR}")
        print(f"       TOP_K         = {cfg.TOP_K_MATCHES}")
        print(f"       ν (air)       = {cfg.NU}")
        print(f"       ρ (air)       = {cfg.RHO}")
        groq_set = bool(cfg.GROQ_API_KEY)
        print(f"       GROQ_API_KEY  = {'SET ✓' if groq_set else 'NOT SET  (set in .env)'}")

    # ── 2. Module imports ──────────────────────────────────────────
    print("\n[2] Module imports")
    check("foam_parser",  lambda: __import__("src.parsers.foam_parser", fromlist=["x"]))
    check("obj_parser",   lambda: __import__("src.parsers.obj_parser",  fromlist=["x"]))
    check("extractor",    lambda: __import__("src.features.extractor",  fromlist=["x"]))
    check("scaling",      lambda: __import__("src.physics.scaling",     fromlist=["x"]))
    check("analyzer",     lambda: __import__("src.physics.analyzer",    fromlist=["x"]))
    check("store",        lambda: __import__("src.vector_db.store",     fromlist=["x"]))
    check("pipeline",     lambda: __import__("src.pipeline",            fromlist=["x"]))

    # ── 3. Sample case parsing ─────────────────────────────────────
    print("\n[3] Sample case parsing  (data/cases/dublin_Spring/building4)")
    sample = Path("data/cases/dublin_Spring/building4")

    if not sample.exists():
        print(f"       [WARN] Sample case not found at {sample}")
        print("       Copy your case there OR set DATASET_ROOT to your cases folder.")
    else:
        from src.parsers.foam_parser import (
            parse_U_bc, parse_k_bc, parse_epsilon_bc,
            parse_mesh_parameters, compute_field_statistics,
        )
        from src.parsers.obj_parser import extract_geometry_features, parse_obj

        u_bc = check("Parse 0/U",
                     lambda: parse_U_bc(sample / "0" / "U"))
        if u_bc:
            Ux, Uy, Uz = u_bc["inlet_velocity"]
            print(f"       inlet = ({Ux}, {Uy}, {Uz}) m/s")

        k_bc = check("Parse 0/k",
                     lambda: parse_k_bc(sample / "0" / "k"))
        if k_bc:
            print(f"       k_inlet = {k_bc['k_inlet']}")

        e_bc = check("Parse 0/epsilon",
                     lambda: parse_epsilon_bc(sample / "0" / "epsilon"))
        if e_bc:
            print(f"       eps_inlet = {e_bc['epsilon_inlet']}")

        mp = check("Parse meshParameters",
                   lambda: parse_mesh_parameters(sample / "system" / "meshParameters"))
        if mp:
            print(f"       domain X: {mp.get('xMin',0):.1f} → {mp.get('xMax',0):.1f}")
            print(f"       domain Y: {mp.get('yMin',0):.1f} → {mp.get('yMax',0):.1f}")
            print(f"       domain Z: {mp.get('zMin',0):.1f} → {mp.get('zMax',0):.1f}")

        obj_path = sample / "constant" / "triSurface" / "buildings.obj"
        geom = check("Parse buildings.obj",
                     lambda: extract_geometry_features(obj_path))
        if geom:
            print(f"       H_building  = {geom['geom_max_height']:.1f} m")
            print(f"       Volume      = {geom['geom_volume']:.0f} m³")
            print(f"       Footprint   = {geom['geom_footprint_area']:.0f} m²")
            print(f"       Aspect XY   = {geom['geom_aspect_ratio_xy']:.3f}")
            print(f"       Vertices    = {int(geom['geom_vertex_count'])}")

        # Field stats (sample only)
        p4 = sample / "4000" / "p"
        u4 = sample / "4000" / "U"
        if p4.exists() and u4.exists():
            stats = check("Read 4000/p + 4000/U stats (sample 5000 cells)",
                          lambda: compute_field_statistics(p4, u4, sample_size=5000))
            if stats:
                print(f"       p_mean = {stats['p_mean']:.2f}  p_max = {stats['p_max']:.2f}")
                print(f"       U_mean = {stats['U_mag_mean']:.3f}  U_max = {stats['U_mag_max']:.3f}")
        else:
            print(f"       [WARN] 4000/p or 4000/U not found — skipping field stats")

    # ── 4. Full feature extraction ─────────────────────────────────
    print("\n[4] Full feature extraction")
    if sample.exists():
        from src.features.extractor import extract_case_features
        import config as cfg2

        has_conv = (sample / str(cfg2.CONVERGENCE_TIME) / "p").exists()
        result = check(
            f"extract_case_features (has_converged={has_conv})",
            lambda: extract_case_features(sample, has_converged_fields=has_conv),
        )
        if result:
            import config as c
            vec = result["feature_vec"]
            print(f"       Feature vector dim = {len(vec)}  (expected {c.FEATURE_DIM})")
            print(f"       Re_building        = {result['features'].get('Re_building',0):.3e}")
            print(f"       inlet_magnitude    = {result['features'].get('inlet_magnitude',0):.3f} m/s")
            print(f"       inlet_azimuth      = {result['features'].get('inlet_azimuth_deg',0):.1f}°")
            nans = sum(1 for v in vec if v != v)  # NaN check
            infs = sum(1 for v in vec if abs(v) == float('inf'))
            print(f"       NaN count = {nans}  Inf count = {infs}"
                  f"  {'✓ clean' if nans+infs==0 else '✗ check features!'}")

    # ── 5. Physics engine ──────────────────────────────────────────
    print("\n[5] Physics engine sanity checks")
    import numpy as np
    from src.physics.scaling import (
        scale_velocity_field, scale_pressure_field,
        rotation_matrix_from_vectors, compute_inlet_turbulence,
    )
    from src.physics.analyzer import full_flow_analysis

    # Rotation matrix test
    def test_rotation():
        v1 = np.array([0, 1, 0])
        v2 = np.array([1, 0, 0])
        R  = rotation_matrix_from_vectors(v1, v2)
        out = R @ v1
        assert abs(out[0] - 1.0) < 1e-9 and abs(out[1]) < 1e-9, f"Rotation failed: {out}"
        return R
    check("Rodrigues rotation matrix", test_rotation)

    # NS scaling test: p ∝ U²
    def test_p_scaling():
        p = np.ones(100) * 10.0
        p_scaled = scale_pressure_field(p, (0, 2, 0), (0, 4, 0))
        ratio = p_scaled[0] / p[0]
        assert abs(ratio - 4.0) < 1e-9, f"Expected 4.0, got {ratio}"
        return ratio
    check("Pressure scaling p ∝ U²", test_p_scaling)

    # NS scaling test: u ∝ U
    def test_u_scaling():
        U = np.tile([0, 2, 0], (100, 1)).astype(float)
        U_sc = scale_velocity_field(U, (0, 2, 0), (0, 6, 0))
        assert abs(U_sc[0, 1] - 6.0) < 1e-9, f"Expected 6.0, got {U_sc[0,1]}"
        return U_sc
    check("Velocity scaling u ∝ U", test_u_scaling)

    # Turbulence inlet computation
    def test_k_eps():
        k, eps = compute_inlet_turbulence(3.0, 60.0, I=0.1)
        assert k > 0 and eps > 0
        return k, eps
    r = check("Turbulence inlet k,ε computation", test_k_eps)
    if r:
        print(f"       k_in={r[0]:.4e}  ε_in={r[1]:.4e}  for U=3m/s, H=60m, I=10%")

    # Full flow analysis on synthetic field
    def test_analysis():
        rng = np.random.default_rng(0)
        p_f = rng.normal(101325, 5, 5000)
        U_f = rng.normal(0, 1, (5000, 3)) + np.array([0, 3, 0])
        return full_flow_analysis(p_f, U_f, (0, 3, 0))
    a = check("Full flow analysis (synthetic field)", test_analysis)
    if a:
        print(f"       risk_level  = {a['structural_risk']['risk_level']}")
        print(f"       wake_frac   = {a['wake_region']['wake_fraction']*100:.1f}%")
        print(f"       Cp_windward = {a['structural_risk']['Cp_windward_max']:.4f}")
        print(f"       Cp_leeward  = {a['structural_risk']['Cp_leeward_min']:.4f}")

    # ── 6. Summary ─────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("  NEXT STEPS:")
    print("=" * 60)
    import config as c2
    if not c2.DATASET_ROOT.exists():
        print(f"  1. Create {c2.DATASET_ROOT} and put your 39 cases inside.")
        print("     Each case needs: 0/U  0/p  0/k  0/epsilon")
        print(f"                      {c2.CONVERGENCE_TIME}/p  {c2.CONVERGENCE_TIME}/U")
        print("                      constant/triSurface/buildings.obj")
    else:
        print(f"  1. DATASET_ROOT already set: {c2.DATASET_ROOT}")

    if not bool(c2.GROQ_API_KEY):
        print("  2. Set GROQ_API_KEY in .env file")
        print("     Get your key from: https://console.groq.com")
    else:
        print("  2. GROQ_API_KEY already set ✓")

    print("  3. python index_cases.py    ← index all 39 cases")
    print("  4. python predict.py --obj buildings.obj --inlet 0 2.6 0 --name test")
    print()


if __name__ == "__main__":
    main()
