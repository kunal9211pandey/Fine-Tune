#!/usr/bin/env python3
"""
batch_predict.py
================
Batch predict p and U fields for multiple new buildings at once.

Reads a CSV or JSON file listing cases to predict, runs the
full RAG pipeline for each, and saves all outputs.

Usage:
  python batch_predict.py --cases cases_to_predict.csv
  python batch_predict.py --cases cases_to_predict.json
  python batch_predict.py --cases cases_to_predict.csv --no-llm

CSV format (one case per row):
  name,obj_path,Ux,Uy,Uz
  building_A,/path/to/A.obj,0,2.6,0
  building_B,/path/to/B.obj,1.5,2.5,0
  building_C,/path/to/C.obj,0,5.0,0

JSON format:
  [
    {"name": "building_A", "obj": "/path/to/A.obj", "inlet": [0, 2.6, 0]},
    {"name": "building_B", "obj": "/path/to/B.obj", "inlet": [1.5, 2.5, 0]},
    ...
  ]
"""
import sys
import csv
import json
import argparse
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from rich.console import Console
from rich.table   import Table
from rich         import box
import numpy as np

import config
from src.pipeline import CFDRagPipeline

console = Console()


def load_cases_csv(path: Path) -> list:
    cases = []
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            cases.append({
                "name":   row.get("name", f"case_{len(cases)}"),
                "obj":    row.get("obj_path", row.get("obj", "")),
                "inlet":  [float(row.get("Ux", 0)),
                           float(row.get("Uy", 0)),
                           float(row.get("Uz", 0))],
            })
    return cases


def load_cases_json(path: Path) -> list:
    with open(path) as f:
        data = json.load(f)
    return [{"name":  c.get("name", f"case_{i}"),
             "obj":   c.get("obj", c.get("obj_path", "")),
             "inlet": c.get("inlet", [0, 0, 0])}
            for i, c in enumerate(data)]


def main():
    p = argparse.ArgumentParser(description="Batch CFD RAG predictions")
    p.add_argument("--cases",   required=True, help="CSV or JSON file with cases to predict")
    p.add_argument("--out",     default=str(config.OUTPUT_DIR), help="Output directory")
    p.add_argument("--top-k",   type=int, default=config.TOP_K_MATCHES)
    p.add_argument("--no-llm",  action="store_true")
    args = p.parse_args()

    cases_file = Path(args.cases)
    if not cases_file.exists():
        console.print(f"[red]File not found:[/] {cases_file}")
        sys.exit(1)

    # Load cases list
    if cases_file.suffix.lower() == ".json":
        cases = load_cases_json(cases_file)
    else:
        cases = load_cases_csv(cases_file)

    console.print(f"[cyan]Loaded {len(cases)} cases from {cases_file}[/]\n")

    if not cases:
        console.print("[red]No cases found in file.[/]")
        sys.exit(1)

    # Validate
    errors = []
    for c in cases:
        if not Path(c["obj"]).exists():
            errors.append(f"OBJ not found: {c['obj']}  (case: {c['name']})")
    if errors:
        for e in errors:
            console.print(f"[red]Error:[/] {e}")
        sys.exit(1)

    if not args.no_llm and not config.GROQ_API_KEY:
        console.print("[red]Error:[/] GROQ_API_KEY not set. Use --no-llm or set key.")
        sys.exit(1)

    # Run predictions
    pipeline = CFDRagPipeline(
        db_path    = config.CHROMA_DB_PATH,
        output_dir = Path(args.out),
        top_k      = args.top_k,
        use_llm    = not args.no_llm,
    )

    results_summary = []
    for i, c in enumerate(cases):
        console.rule(f"[cyan]Case {i+1}/{len(cases)}: {c['name']}")
        inlet = tuple(c["inlet"])
        try:
            result = pipeline.predict(
                inlet_velocity = inlet,
                obj_path       = Path(c["obj"]),
                case_name      = c["name"],
            )
            kp = result["key_physics"]
            results_summary.append({
                "name":           c["name"],
                "status":         "OK",
                "Cp_windward":    kp["Cp_windward_max"],
                "Cp_leeward":     kp["Cp_leeward_min"],
                "delta_p_Pa":     kp["delta_p_Pa"],
                "risk":           kp["risk_level"],
                "wake_pct":       kp["wake_fraction_pct"],
                "max_speed_ratio": kp["max_speed_ratio"],
                "output_dir":     result["output_dir"],
            })
        except Exception as e:
            console.print(f"[red]Failed:[/] {c['name']}  →  {e}")
            traceback.print_exc()
            results_summary.append({
                "name": c["name"], "status": f"FAILED: {e}",
                "Cp_windward": None, "Cp_leeward": None,
                "delta_p_Pa": None, "risk": "?", "wake_pct": None,
                "max_speed_ratio": None, "output_dir": None,
            })

    # Print summary table
    console.rule("[bold green]Batch Complete")
    t = Table(title="Batch Prediction Summary", box=box.SIMPLE_HEAVY)
    t.add_column("Case",        style="cyan", no_wrap=True)
    t.add_column("Status",      justify="center")
    t.add_column("Cp_wind",     justify="right")
    t.add_column("Cp_lee",      justify="right")
    t.add_column("ΔP Pa",       justify="right")
    t.add_column("Risk",        justify="center")
    t.add_column("Wake %",      justify="right")
    t.add_column("Max U/Uin",   justify="right")

    for r in results_summary:
        ok = r["status"] == "OK"
        t.add_row(
            r["name"][:35],
            "[green]OK[/]" if ok else f"[red]{r['status'][:15]}[/]",
            f"{r['Cp_windward']:.4f}" if ok else "-",
            f"{r['Cp_leeward']:.4f}"  if ok else "-",
            f"{r['delta_p_Pa']:.1f}"  if ok else "-",
            r["risk"],
            f"{r['wake_pct']:.2f}"    if ok else "-",
            f"{r['max_speed_ratio']:.4f}" if ok else "-",
        )
    console.print(t)

    # Save summary JSON
    summary_path = Path(args.out) / "batch_summary.json"
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    with open(summary_path, "w") as f:
        json.dump(results_summary, f, indent=2, default=str)
    console.print(f"\n[green]Summary saved:[/] [cyan]{summary_path}[/]")

    # Quick stats
    ok_cases  = [r for r in results_summary if r["status"] == "OK"]
    fail_cases = [r for r in results_summary if r["status"] != "OK"]
    console.print(f"\n  [green]Succeeded:[/] {len(ok_cases)}/{len(cases)}")
    if fail_cases:
        console.print(f"  [red]Failed:[/]    {len(fail_cases)}")
        for f in fail_cases:
            console.print(f"    - {f['name']}: {f['status']}")


if __name__ == "__main__":
    main()
