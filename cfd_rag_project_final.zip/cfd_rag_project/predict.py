#!/usr/bin/env python3
"""
predict.py
==========
Physics-Based CFD RAG — Prediction CLI.

Takes inlet velocity + buildings.obj as input.
Writes OpenFOAM p, U, k, epsilon, BC files + reports as output.
NO interactive mode. NO Q&A. Single execution → result files.

Usage
-----
# Velocity vector directly:
python predict.py --obj /path/to/buildings.obj --inlet 0 2.6 0 --name my_building

# Speed + compass direction:
python predict.py --obj /path/to/buildings.obj --speed 5.0 --direction S --name my_building

# Without LLM (faster, nearest-neighbour physics scaling only):
python predict.py --obj /path/to/buildings.obj --inlet 1.5 2.5 0 --no-llm

Wind directions:  N  NE  E  SE  S  SW  W  NW
"""
import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import numpy as np
from rich.console import Console

import config
from src.pipeline import CFDRagPipeline

console = Console()


def parse_args():
    p = argparse.ArgumentParser(
        description="CFD Physics RAG — predict p & U fields",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--obj",    required=True, help="Path to buildings.obj")
    p.add_argument("--name",   default="predicted_case", help="Output case name")
    p.add_argument("--system", default=None, help="Path to system/ directory")
    p.add_argument("--top-k",  type=int, default=config.TOP_K_MATCHES)
    p.add_argument("--out",    default=str(config.OUTPUT_DIR), help="Output root dir")
    p.add_argument("--no-llm", action="store_true", help="Skip LLM, use nearest-neighbour only")

    grp = p.add_mutually_exclusive_group(required=True)
    grp.add_argument("--inlet",  nargs=3, type=float, metavar=("Ux","Uy","Uz"),
                     help="Inlet velocity vector e.g. --inlet 0 2.6 0")
    grp.add_argument("--speed",  type=float, help="Wind speed magnitude m/s")

    p.add_argument("--direction", default="S",
                   choices=list(config.WIND_DIRECTIONS.keys()),
                   help="Compass direction when using --speed")
    return p.parse_args()


def main():
    args = parse_args()

    # ── Resolve inlet velocity ────────────────────────────────────────────
    if args.inlet:
        inlet = tuple(args.inlet)
    else:
        dx, dy, dz = config.WIND_DIRECTIONS[args.direction.upper()]
        inlet = (args.speed * dx, args.speed * dy, args.speed * dz)

    obj_path   = Path(args.obj)
    system_dir = Path(args.system) if args.system else None
    output_dir = Path(args.out)

    # ── Validate ──────────────────────────────────────────────────────────
    if not obj_path.exists():
        console.print(f"[red]Error:[/] OBJ not found: {obj_path}")
        sys.exit(1)

    U_mag = float(np.linalg.norm(inlet))
    if U_mag < 0.01:
        console.print("[yellow]Warning:[/] Near-zero inlet velocity.")

    if not args.no_llm and not config.GROQ_API_KEY:
        console.print("[red]Error:[/] GROQ_API_KEY not set in .env")
        console.print("Add it to .env file or use --no-llm flag.")
        sys.exit(1)

    # ── Run prediction ────────────────────────────────────────────────────
    pipeline = CFDRagPipeline(
        db_path    = config.CHROMA_DB_PATH,
        output_dir = output_dir,
        top_k      = args.top_k,
        use_llm    = not args.no_llm,
    )

    result = pipeline.predict(
        inlet_velocity = inlet,
        obj_path       = obj_path,
        case_name      = args.name,
        system_dir     = system_dir,
    )

    # Print final key numbers
    kp = result["key_physics"]
    console.print("\n[bold green]Prediction complete.[/]")
    console.print(f"  Re               = {kp['Re_building']:.3e}")
    console.print(f"  Cp_windward_max  = {kp['Cp_windward_max']:.4f}")
    console.print(f"  Cp_leeward_min   = {kp['Cp_leeward_min']:.4f}")
    console.print(f"  ΔP (Pa)          = {kp['delta_p_Pa']:.2f}")
    console.print(f"  Risk level       = [bold]{kp['risk_level']}[/bold]")
    console.print(f"  Wake fraction    = {kp['wake_fraction_pct']:.2f}%")
    console.print(f"  Max speed ratio  = {kp['max_speed_ratio']:.4f}×")
    console.print(f"\n  Output dir: [cyan]{result['output_dir']}[/]")


if __name__ == "__main__":
    main()
