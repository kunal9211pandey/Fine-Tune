"""
Global configuration for CFD Physics-Based RAG System.
All physics constants and system settings live here.
"""
import os
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()

# ─── Groq LLM ──────────────────────────────────────────────────────────────
GROQ_API_KEY   = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL     = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

# ─── Paths ──────────────────────────────────────────────────────────────────
BASE_DIR       = Path(__file__).parent
DATASET_ROOT   = Path(os.getenv("DATASET_ROOT", BASE_DIR / "data" / "cases"))
CHROMA_DB_PATH = Path(os.getenv("CHROMA_DB_PATH", BASE_DIR / "data" / "vector_db"))
OUTPUT_DIR     = Path(os.getenv("OUTPUT_DIR", BASE_DIR / "output"))

# ─── RAG settings ───────────────────────────────────────────────────────────
TOP_K_MATCHES  = int(os.getenv("TOP_K_MATCHES", 5))

# ─── Physics constants (incompressible air at standard conditions) ───────────
NU  = float(os.getenv("NU", 1.5e-5))    # kinematic viscosity [m²/s]
RHO = float(os.getenv("RHO", 1.225))    # density [kg/m³]
TURBULENCE_INTENSITY = float(os.getenv("TURBULENCE_INTENSITY", 0.1))  # I = 0.1 = 10%

# ─── OpenFOAM solver config (mirrors actual setup) ──────────────────────────
SOLVER            = "simpleFoam"       # steady-state incompressible RANS
TURBULENCE_MODEL  = "kEpsilon"         # k-ε two-equation model
CONVERGENCE_TIME  = 4000               # final timestep used as ground truth
NU_T_WALL_FUNC    = "nutkWallFunction" # turbulent viscosity wall function

# ─── Navier-Stokes physics model keys ───────────────────────────────────────
# These are used by the physics engine for NS-based field scaling
# Governing equations (incompressible, steady RANS):
#   ∇·u = 0                                     (continuity)
#   (u·∇)u = -∇(p/ρ) + ∇·[(ν+νt)(∇u+∇uᵀ)]    (momentum)
#   (u·∇)k = ∇·[(ν+νt/σk)∇k] + Pk - ε          (k transport)
#   (u·∇)ε = ∇·[(ν+νt/σε)∇ε] + C1ε(ε/k)Pk - C2ε(ε²/k)  (ε transport)
#
# k-ε model coefficients (standard):
CMU   = 0.09     # Cμ  - eddy viscosity coefficient
C1E   = 1.44     # C1ε - ε production coefficient
C2E   = 1.92     # C2ε - ε destruction coefficient
SIGMA_K = 1.0    # σk  - turbulent Prandtl number for k
SIGMA_E = 1.3    # σε  - turbulent Prandtl number for ε

# ─── OpenFOAM dimensions (SI unit exponents: [kg m s K mol A cd]) ───────────
DIM_U  = "[0 1 -1 0 0 0 0]"   # velocity [m/s]
DIM_P  = "[0 2 -2 0 0 0 0]"   # kinematic pressure [m²/s²]
DIM_K  = "[0 2 -2 0 0 0 0]"   # turbulent KE [m²/s²]
DIM_E  = "[0 2 -3 0 0 0 0]"   # dissipation rate [m²/s³]
DIM_NU = "[0 2 -1 0 0 0 0]"   # kinematic viscosity [m²/s]

# ─── Feature vector config ───────────────────────────────────────────────────
FEATURE_NAMES = [
    # Inlet velocity (6 features)
    "inlet_Ux", "inlet_Uy", "inlet_Uz",
    "inlet_magnitude", "inlet_azimuth_deg", "inlet_elevation_deg",
    # Turbulence at inlet (3 features)
    "k_inlet", "epsilon_inlet", "turbulence_intensity",
    # Reynolds number (1 feature)
    "Re_building",
    # Geometry - bounding box (6 features)
    "geom_bbox_x", "geom_bbox_y", "geom_bbox_z",
    "geom_centroid_x", "geom_centroid_y", "geom_centroid_z",
    # Geometry - shape descriptors (6 features)
    "geom_volume", "geom_surface_area", "geom_max_height",
    "geom_footprint_area", "geom_aspect_ratio_xy", "geom_vertex_count",
    # Domain (3 features)
    "domain_x_span", "domain_y_span", "domain_z_span",
    # Field statistics from converged solution (8 features)
    "p_mean", "p_max", "p_min", "p_std",
    "U_mag_mean", "U_mag_max", "U_mag_min", "U_mag_std",
]

FEATURE_DIM = len(FEATURE_NAMES)  # 33 features

# ─── Directions ─────────────────────────────────────────────────────────────
WIND_DIRECTIONS = {
    "N":  (0,  -1, 0), "NE": ( 0.707, -0.707, 0),
    "E":  (1,   0, 0), "SE": ( 0.707,  0.707, 0),
    "S":  (0,   1, 0), "SW": (-0.707,  0.707, 0),
    "W":  (-1,  0, 0), "NW": (-0.707, -0.707, 0),
}
