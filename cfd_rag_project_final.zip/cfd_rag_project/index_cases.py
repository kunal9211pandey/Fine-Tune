#!/usr/bin/env python3
"""
index_cases.py
==============
Index all CFD cases from DATASET_ROOT into the ChromaDB vector store.

Run ONCE before using predict.py.
Re-run any time you add new cases.

Expected dataset structure under DATASET_ROOT:
  <location>_<season>/
    building2/
      0/U  0/p  0/k  0/epsilon  0/nut
      4000/p  4000/U  4000/k  4000/epsilon
      constant/triSurface/buildings.obj
      constant/momentumTransport
      constant/transportProperties
    building3/
    building4/   ← (the sample you provided)
    building5/
  OR any flat structure where each case has 0/U and 4000/p.

What it does:
  1. Discover all valid OpenFOAM case directories
  2. Extract 33-dim physics feature vectors from each
  3. Fit Z-score normaliser on the full corpus
  4. Store all vectors + metadata in ChromaDB (persistent, on disk)
  5. Save case_manifest.json for reference
"""
import sys
import json
from pathlib import Path

import numpy as np
from tqdm import tqdm
from rich.console import Console
from rich.table   import Table
from rich         import box

sys.path.insert(0, str(Path(__file__).parent))

import config
from src.features.extractor import extract_case_features
from src.vector_db.store    import CFDVectorStore

console = Console()


def discover_cases(root: Path) -> list:
    """Find all valid OpenFOAM case dirs (must have 0/U and 4000/p)."""
    found = []
    for u_file in sorted(root.rglob("0/U")):
        cdir = u_file.parent.parent
        if (cdir / str(config.CONVERGENCE_TIME) / "p").exists():
            found.append(cdir)
    # Deduplicate
    seen = set()
    unique = []
    for c in found:
        if str(c) not in seen:
            seen.add(str(c))
            unique.append(c)
    return unique


def case_id_from_path(case_dir: Path, root: Path) -> str:
    try:
        rel = case_dir.relative_to(root)
    except ValueError:
        rel = Path(case_dir.name)
    return str(rel).replace("/","_").replace("\\","_").replace(" ","_")


def main():
    console.rule("[bold cyan]CFD RAG Indexer")

    root = config.DATASET_ROOT
    if not root.exists():
        console.print(f"[red]DATASET_ROOT not found:[/] {root}")
        console.print("Set DATASET_ROOT in your .env file.")
        sys.exit(1)

    console.print(f"Scanning: [cyan]{root}[/]")
    cases = discover_cases(root)
    if not cases:
        console.print("[red]No valid CFD cases found.[/]")
        console.print("Each case needs: 0/U  and  4000/p")
        sys.exit(1)

    console.print(f"[green]Found {len(cases)} case(s)[/]\n")
    store = CFDVectorStore(config.CHROMA_DB_PATH)

    # ── Phase 1: Extract features ─────────────────────────────────────────
    console.print("[bold]Phase 1 — Feature extraction[/]")
    ids, feats, raws, vecs, failed = [], [], [], [], []

    for cdir in tqdm(cases, desc="Extracting"):
        cid = case_id_from_path(cdir, root)
        try:
            res = extract_case_features(cdir, has_converged_fields=True)
            ids.append(cid)
            feats.append(res["features"])
            raws.append(res["raw"])
            vecs.append(res["feature_vec"])
        except Exception as e:
            console.print(f"  [yellow]Failed:[/] {cid}  →  {e}")
            failed.append(cid)

    console.print(f"[green]Extracted:[/] {len(ids)}/{len(cases)}   "
                  f"[yellow]Failed:[/] {len(failed)}")

    if not ids:
        console.print("[red]Nothing to index.[/]")
        sys.exit(1)

    # ── Phase 2: Fit normaliser ───────────────────────────────────────────
    console.print("\n[bold]Phase 2 — Fitting normaliser[/]")
    store.fit_normaliser(vecs)
    console.print("[green]Normaliser fitted and saved.[/]")

    # ── Phase 3: Index into ChromaDB ──────────────────────────────────────
    console.print("\n[bold]Phase 3 — Indexing into ChromaDB[/]")
    for cid, feat, raw, vec in tqdm(
            zip(ids, feats, raws, vecs), total=len(ids), desc="Indexing"):
        doc = CFDVectorStore.build_document(cid, feat, raw)
        store.add_case(cid, vec, feat, raw, doc)

    console.print(f"\n[green]Vector DB total: {store.count()} cases[/]")
    console.print(f"Location: [cyan]{config.CHROMA_DB_PATH}[/]")

    # ── Summary table ─────────────────────────────────────────────────────
    tbl = Table(title="Indexed Cases", box=box.SIMPLE_HEAVY)
    tbl.add_column("Case ID",   style="cyan", no_wrap=True)
    tbl.add_column("|U| m/s",   justify="right")
    tbl.add_column("Azi °",     justify="right")
    tbl.add_column("H m",       justify="right")
    tbl.add_column("Re",        justify="right")
    tbl.add_column("Cp_max",    justify="right")
    tbl.add_column("Cp_min",    justify="right")
    tbl.add_column("Risk",      justify="right")

    for cid, feat in zip(ids, feats):
        q = 0.5 * feat.get("inlet_magnitude", 1)**2 + 1e-9
        cpm = (feat.get("p_max",0) - feat.get("p_mean",0)) / q
        cpn = (feat.get("p_min",0) - feat.get("p_mean",0)) / q
        risk = ("HIGH" if abs(cpn)>1.5 or cpm>0.9
                else "MED" if abs(cpn)>0.8 or cpm>0.6
                else "LOW")
        tbl.add_row(
            cid[:48],
            f"{feat.get('inlet_magnitude',0):.3f}",
            f"{feat.get('inlet_azimuth_deg',0):.1f}",
            f"{feat.get('geom_max_height',0):.1f}",
            f"{feat.get('Re_building',0):.2e}",
            f"{cpm:.3f}", f"{cpn:.3f}", risk,
        )
    console.print(tbl)

    # ── Save manifest ─────────────────────────────────────────────────────
    config.CHROMA_DB_PATH.mkdir(parents=True, exist_ok=True)
    manifest = [{"id": cid, "case_dir": str(raw["case_dir"]),
                 "inlet": list(raw["inlet_velocity"]),
                 "U_mag": round(feat.get("inlet_magnitude",0), 4)}
                for cid, feat, raw in zip(ids, feats, raws)]
    mp = config.CHROMA_DB_PATH / "case_manifest.json"
    mp.write_text(json.dumps(manifest, indent=2))
    console.print(f"[green]Manifest:[/] [cyan]{mp}[/]")

    console.rule("[bold green]Indexing complete → run  python predict.py  next")


if __name__ == "__main__":
    main()
