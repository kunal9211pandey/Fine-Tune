#!/usr/bin/env python3
"""
prepare_dataset.py
==================
Helper script to organize your 39 CFD cases into the correct
directory structure expected by index_cases.py.

Use this if your cases are:
  - Stored as zip files
  - In a different folder layout
  - Mixed locations (dublin, mohali, mombasa)

Supported input layouts:
  A) Already correct OpenFOAM structure (just sets DATASET_ROOT)
  B) Zip files per case
  C) Flat folder with all cases mixed

Usage:
  python prepare_dataset.py --scan /path/to/your/cases
  python prepare_dataset.py --scan /path/to/your/cases --copy-to ./data/cases

What "correct structure" means for each case:
  <case_name>/
    0/U  0/p  0/k  0/epsilon  0/nut
    <timestep>/p  <timestep>/U          ← timestep from config.CONVERGENCE_TIME (4000)
    constant/triSurface/buildings.obj
    system/meshParameters
"""
import sys
import shutil
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import config

try:
    from rich.console import Console
    from rich.table   import Table
    from rich         import box
    console = Console()
except ImportError:
    class _C:
        def print(self, *a, **k): print(*a)
        def rule(self, *a, **k): print("-"*60)
    console = _C()


REQUIRED_FILES = [
    "0/U", "0/p", "0/k", "0/epsilon",
    f"{config.CONVERGENCE_TIME}/p",
    f"{config.CONVERGENCE_TIME}/U",
    "constant/triSurface/buildings.obj",
]

OPTIONAL_FILES = [
    f"{config.CONVERGENCE_TIME}/k",
    f"{config.CONVERGENCE_TIME}/epsilon",
    "system/meshParameters",
    "constant/momentumTransport",
    "constant/transportProperties",
]


def check_case(path: Path) -> dict:
    """Check if a directory is a valid CFD case."""
    present  = [f for f in REQUIRED_FILES if (path / f).exists()]
    missing  = [f for f in REQUIRED_FILES if not (path / f).exists()]
    optional = [f for f in OPTIONAL_FILES  if (path / f).exists()]

    # Try to read inlet velocity
    inlet = None
    u_file = path / "0" / "U"
    if u_file.exists():
        try:
            import re
            txt = u_file.read_text(errors="replace")
            m   = re.search(r'Uinlet\s+\(([^)]+)\)', txt)
            if m:
                vals  = list(map(float, m.group(1).split()))
                inlet = tuple(vals[:3])
        except Exception:
            pass

    return {
        "path":     path,
        "name":     path.name,
        "valid":    len(missing) == 0,
        "present":  present,
        "missing":  missing,
        "optional": optional,
        "inlet":    inlet,
        "n_req":    len(present),
        "n_total":  len(REQUIRED_FILES),
    }


def scan_directory(root: Path) -> list:
    """Recursively find all potential OpenFOAM case directories."""
    found = []
    seen  = set()
    # Look for directories containing 0/U
    for u_file in sorted(root.rglob("0/U")):
        cdir = u_file.parent.parent
        if str(cdir) not in seen:
            seen.add(str(cdir))
            found.append(check_case(cdir))
    return found


def print_scan_results(cases: list):
    console.rule("[bold]Scan Results")
    valid   = [c for c in cases if c["valid"]]
    partial = [c for c in cases if not c["valid"] and c["n_req"] > 0]
    empty   = [c for c in cases if c["n_req"] == 0]

    console.print(f"  Total found   : {len(cases)}")
    console.print(f"  [green]Valid cases[/]   : {len(valid)}")
    console.print(f"  [yellow]Partial cases[/] : {len(partial)}  (some required files missing)")
    console.print(f"  [red]Empty dirs[/]    : {len(empty)}")

    if valid or partial:
        try:
            t = Table(title="Case Status", box=box.SIMPLE_HEAVY)
            t.add_column("Case Name",  style="cyan", no_wrap=True)
            t.add_column("Valid",      justify="center")
            t.add_column("Files",      justify="right")
            t.add_column("Inlet m/s",  justify="right")
            t.add_column("Missing",    style="red", no_wrap=True)

            for c in (valid + partial):
                inlet_str = (f"({c['inlet'][0]:.2f},{c['inlet'][1]:.2f},{c['inlet'][2]:.2f})"
                             if c["inlet"] else "?")
                missing_str = ", ".join(c["missing"][:2]) + ("..." if len(c["missing"]) > 2 else "")
                t.add_row(
                    str(c["path"])[:50],
                    "✓" if c["valid"] else "✗",
                    f"{c['n_req']}/{c['n_total']}",
                    inlet_str,
                    missing_str,
                )
            console.print(t)
        except Exception:
            for c in (valid + partial):
                print(f"  {'OK' if c['valid'] else 'XX'}  {c['path']}")

    return valid, partial


def copy_cases(cases: list, dest: Path):
    """Copy valid cases to dest/ maintaining original structure."""
    dest.mkdir(parents=True, exist_ok=True)
    for c in cases:
        case_path = Path(c["path"])
        # Destination: dest/<parent_name>/<case_name>  if parent != root
        dst = dest / case_path.parent.name / case_path.name
        if dst.exists():
            console.print(f"  [yellow]Skip[/] {dst.name}  (already exists)")
            continue
        console.print(f"  Copying  {case_path.name} → {dst}")
        shutil.copytree(
            case_path, dst,
            ignore=shutil.ignore_patterns("polyMesh"),  # skip large mesh
        )
    console.print(f"[green]Done. {len(cases)} cases copied to {dest}[/]")


def main():
    p = argparse.ArgumentParser(description="Prepare CFD dataset for RAG indexing")
    p.add_argument("--scan",    required=True, help="Directory to scan for CFD cases")
    p.add_argument("--copy-to", default=None,  help="Copy valid cases here (optional)")
    p.add_argument("--show-missing", action="store_true",
                   help="Show all missing files per case")
    args = p.parse_args()

    root = Path(args.scan)
    if not root.exists():
        console.print(f"[red]Error:[/] Directory not found: {root}")
        sys.exit(1)

    console.rule("[bold cyan]CFD Dataset Preparation")
    console.print(f"Scanning: [cyan]{root}[/]\n")

    cases = scan_directory(root)
    if not cases:
        console.print("[red]No OpenFOAM cases found.[/]")
        console.print("Looking for directories containing: 0/U")
        sys.exit(1)

    valid, partial = print_scan_results(cases)

    if args.show_missing:
        console.print("\n[bold]Missing files detail:[/]")
        for c in partial:
            console.print(f"  {c['path'].name}:")
            for m in c["missing"]:
                console.print(f"    ✗  {m}")

    if args.copy_to:
        dest = Path(args.copy_to)
        console.print(f"\nCopying {len(valid)} valid cases to: [cyan]{dest}[/]")
        copy_cases(valid, dest)
        console.print(f"\nNow update your .env:")
        console.print(f"  DATASET_ROOT={dest.resolve()}")
    else:
        console.print(f"\n[bold]To index these {len(valid)} cases:[/]")
        console.print(f"  1. Update .env:  DATASET_ROOT={root.resolve()}")
        console.print(f"  2. Run:          python index_cases.py")

    if partial:
        console.print(f"\n[yellow]Warning:[/] {len(partial)} cases have missing files.")
        console.print("These will be skipped during indexing.")
        console.print("Run with --show-missing to see which files are missing.")


if __name__ == "__main__":
    main()
